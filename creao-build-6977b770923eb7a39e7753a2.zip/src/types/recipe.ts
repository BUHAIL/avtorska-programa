export type RecipeCategory = "Fast" | "Medium" | "Regular";
export type RecipeDifficulty = "Easy" | "Medium" | "Hard";

export interface Recipe {
	id: string;
	title: string;
	description: string;
	ingredients: string[];
	instructions: string[];
	category: RecipeCategory;
	cookingTime: number;
	difficulty: RecipeDifficulty;
	generatedAt: string;
}

export interface UserPreferences {
	dietaryPreferences: string[];
	dislikedIngredients: string[];
	healthGoals: string[];
	preferredCuisines: string[];
}

export interface SubscriptionInfo {
	isPremium: boolean;
	subscriptionExpiresAt: string | null;
	selectedTheme: string;
}

export type Theme = "default" | "dark" | "ocean" | "sunset" | "forest";

export interface ThemeInfo {
	id: Theme;
	name: string;
	premium: boolean;
}
