import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { RecipeHistoryORM, type RecipeHistoryModel, RecipeHistoryCategory } from "@/sdk/database/orm/orm_recipe_history";
import { APP_CONFIG } from "@/sdk/core/global";
import type { Recipe, RecipeCategory } from "@/types/recipe";

/**
 * Hook to manage recipe history with database persistence
 */
export function useRecipeHistory() {
	const queryClient = useQueryClient();
	const userId = APP_CONFIG.userId || "anonymous";
	const orm = RecipeHistoryORM.getInstance();

	// Fetch recipe history
	const { data: recipes, isLoading } = useQuery({
		queryKey: ["recipeHistory", userId],
		queryFn: async (): Promise<Recipe[]> => {
			const result = await orm.getRecipeHistoryByUserId(userId);

			return result.map((r) => ({
				id: r.id,
				title: r.title,
				description: r.description,
				ingredients: r.ingredients,
				instructions: r.instructions,
				category: categoryFromEnum(r.category),
				cookingTime: r.cooking_time,
				difficulty: r.difficulty as Recipe["difficulty"],
				generatedAt: r.generated_at,
			}));
		},
	});

	// Save recipes to history
	const saveRecipes = useMutation({
		mutationFn: async (recipesToSave: Recipe[]) => {
			const historyData: Partial<RecipeHistoryModel>[] = recipesToSave.map((r) => ({
				user_id: userId,
				title: r.title,
				description: r.description,
				ingredients: r.ingredients,
				instructions: r.instructions,
				category: categoryToEnum(r.category),
				cooking_time: r.cookingTime,
				difficulty: r.difficulty,
				generated_at: r.generatedAt,
			}));

			await orm.insertRecipeHistory(historyData as RecipeHistoryModel[]);
		},
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["recipeHistory", userId] });
		},
	});

	return {
		recipes: recipes || [],
		isLoading,
		saveRecipes: saveRecipes.mutate,
		isSaving: saveRecipes.isPending,
	};
}

function categoryToEnum(category: RecipeCategory): RecipeHistoryCategory {
	switch (category) {
		case "Fast":
			return RecipeHistoryCategory.Fast;
		case "Medium":
			return RecipeHistoryCategory.Medium;
		case "Regular":
			return RecipeHistoryCategory.Regular;
		default:
			return RecipeHistoryCategory.Unspecified;
	}
}

function categoryFromEnum(category: RecipeHistoryCategory): RecipeCategory {
	switch (category) {
		case RecipeHistoryCategory.Fast:
			return "Fast";
		case RecipeHistoryCategory.Medium:
			return "Medium";
		case RecipeHistoryCategory.Regular:
			return "Regular";
		default:
			return "Medium";
	}
}
