import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { SubscriptionStateORM, type SubscriptionStateModel } from "@/sdk/database/orm/orm_subscription_state";
import { APP_CONFIG } from "@/sdk/core/global";
import type { SubscriptionInfo, Theme } from "@/types/recipe";

/**
 * Hook to manage subscription state with database persistence
 */
export function useSubscription() {
	const queryClient = useQueryClient();
	const userId = APP_CONFIG.userId || "anonymous";
	const orm = SubscriptionStateORM.getInstance();

	// Fetch subscription state
	const { data: subscription, isLoading } = useQuery({
		queryKey: ["subscription", userId],
		queryFn: async (): Promise<SubscriptionInfo> => {
			const result = await orm.getSubscriptionStateByUserId(userId);

			if (result.length === 0) {
				// Return default state if none exists
				return {
					isPremium: false,
					subscriptionExpiresAt: null,
					selectedTheme: "default",
				};
			}

			const sub = result[0];
			return {
				isPremium: sub.is_premium,
				subscriptionExpiresAt: sub.subscription_expires_at || null,
				selectedTheme: sub.selected_theme,
			};
		},
	});

	// Update subscription (for demo - activating premium)
	const upgradeToPremium = useMutation({
		mutationFn: async () => {
			const existing = await orm.getSubscriptionStateByUserId(userId);

			// Set expiration to 1 year from now
			const expiresAt = new Date();
			expiresAt.setFullYear(expiresAt.getFullYear() + 1);

			const subData: Partial<SubscriptionStateModel> = {
				user_id: userId,
				is_premium: true,
				subscription_expires_at: Math.floor(expiresAt.getTime() / 1000).toString(),
				selected_theme: existing.length > 0 ? existing[0].selected_theme : "default",
			};

			if (existing.length > 0) {
				const updated = { ...existing[0], ...subData };
				await orm.setSubscriptionStateByUserId(userId, updated as SubscriptionStateModel);
			} else {
				await orm.insertSubscriptionState([subData as SubscriptionStateModel]);
			}
		},
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["subscription", userId] });
		},
	});

	// Update theme
	const updateTheme = useMutation({
		mutationFn: async (theme: Theme) => {
			const existing = await orm.getSubscriptionStateByUserId(userId);

			const subData: Partial<SubscriptionStateModel> = {
				user_id: userId,
				is_premium: existing.length > 0 ? existing[0].is_premium : false,
				subscription_expires_at:
					existing.length > 0 ? existing[0].subscription_expires_at : null,
				selected_theme: theme,
			};

			if (existing.length > 0) {
				const updated = { ...existing[0], ...subData };
				await orm.setSubscriptionStateByUserId(userId, updated as SubscriptionStateModel);
			} else {
				await orm.insertSubscriptionState([subData as SubscriptionStateModel]);
			}
		},
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["subscription", userId] });
		},
	});

	return {
		subscription: subscription || {
			isPremium: false,
			subscriptionExpiresAt: null,
			selectedTheme: "default",
		},
		isLoading,
		upgradeToPremium: upgradeToPremium.mutate,
		isUpgrading: upgradeToPremium.isPending,
		updateTheme: updateTheme.mutate,
		isUpdatingTheme: updateTheme.isPending,
	};
}
