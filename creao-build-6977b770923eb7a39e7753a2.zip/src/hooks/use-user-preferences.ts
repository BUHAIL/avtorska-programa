import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { UserPreferenceORM, type UserPreferenceModel } from "@/sdk/database/orm/orm_user_preference";
import { APP_CONFIG } from "@/sdk/core/global";
import type { UserPreferences } from "@/types/recipe";

/**
 * Hook to manage user preferences with database persistence
 */
export function useUserPreferences() {
	const queryClient = useQueryClient();
	const userId = APP_CONFIG.userId || "anonymous";
	const orm = UserPreferenceORM.getInstance();

	// Fetch user preferences
	const { data: preferences, isLoading } = useQuery({
		queryKey: ["userPreferences", userId],
		queryFn: async (): Promise<UserPreferences> => {
			const result = await orm.getUserPreferenceByUserId(userId);

			if (result.length === 0) {
				// Return default preferences if none exist
				return {
					dietaryPreferences: [],
					dislikedIngredients: [],
					healthGoals: [],
					preferredCuisines: [],
				};
			}

			const pref = result[0];
			return {
				dietaryPreferences: pref.dietary_preferences || [],
				dislikedIngredients: pref.disliked_ingredients || [],
				healthGoals: pref.health_goals || [],
				preferredCuisines: pref.preferred_cuisines || [],
			};
		},
	});

	// Update user preferences
	const updateMutation = useMutation({
		mutationFn: async (newPreferences: UserPreferences) => {
			// Check if preferences exist
			const existing = await orm.getUserPreferenceByUserId(userId);

			const prefData: Partial<UserPreferenceModel> = {
				user_id: userId,
				dietary_preferences: newPreferences.dietaryPreferences,
				disliked_ingredients: newPreferences.dislikedIngredients,
				health_goals: newPreferences.healthGoals,
				preferred_cuisines: newPreferences.preferredCuisines,
			};

			if (existing.length > 0) {
				// Update existing
				const updated = { ...existing[0], ...prefData };
				await orm.setUserPreferenceByUserId(userId, updated as UserPreferenceModel);
			} else {
				// Create new
				await orm.insertUserPreference([prefData as UserPreferenceModel]);
			}
		},
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["userPreferences", userId] });
		},
	});

	return {
		preferences: preferences || {
			dietaryPreferences: [],
			dislikedIngredients: [],
			healthGoals: [],
			preferredCuisines: [],
		},
		isLoading,
		updatePreferences: updateMutation.mutate,
		isUpdating: updateMutation.isPending,
	};
}
