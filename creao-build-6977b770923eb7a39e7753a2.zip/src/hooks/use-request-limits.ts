import { useState, useCallback, useEffect } from "react";
import { APP_CONFIG } from "@/sdk/core/global";

const FREE_DAILY_LIMIT = 5;
const STORAGE_KEY_PREFIX = "chefai_requests_";

interface RequestLimitsState {
	remainingRequests: number;
	resetTime: Date | null;
	isLimitExhausted: boolean;
}

interface StoredLimitsData {
	count: number;
	resetTime: string;
}

/**
 * Hook to manage daily request limits for free users
 * Pro users have unlimited requests
 */
export function useRequestLimits(isPremium: boolean) {
	const userId = APP_CONFIG.userId || "anonymous";
	const storageKey = `${STORAGE_KEY_PREFIX}${userId}`;

	const getStoredData = useCallback((): StoredLimitsData | null => {
		try {
			const stored = localStorage.getItem(storageKey);
			if (stored) {
				return JSON.parse(stored) as StoredLimitsData;
			}
		} catch {
			// Ignore parse errors
		}
		return null;
	}, [storageKey]);

	const getResetTime = useCallback((): Date => {
		const now = new Date();
		const reset = new Date(now);
		reset.setHours(24, 0, 0, 0); // Next midnight
		return reset;
	}, []);

	const initializeLimits = useCallback((): RequestLimitsState => {
		// Premium users have unlimited requests
		if (isPremium) {
			return {
				remainingRequests: -1, // -1 means unlimited
				resetTime: null,
				isLimitExhausted: false,
			};
		}

		const stored = getStoredData();
		const now = new Date();

		// Check if we have stored data and if it's still valid
		if (stored) {
			const storedResetTime = new Date(stored.resetTime);

			// If reset time has passed, reset the counter
			if (now >= storedResetTime) {
				const newResetTime = getResetTime();
				const newData: StoredLimitsData = {
					count: 0,
					resetTime: newResetTime.toISOString(),
				};
				localStorage.setItem(storageKey, JSON.stringify(newData));

				return {
					remainingRequests: FREE_DAILY_LIMIT,
					resetTime: newResetTime,
					isLimitExhausted: false,
				};
			}

			// Data is still valid
			const remaining = FREE_DAILY_LIMIT - stored.count;
			return {
				remainingRequests: Math.max(0, remaining),
				resetTime: storedResetTime,
				isLimitExhausted: remaining <= 0,
			};
		}

		// No stored data, initialize fresh
		const newResetTime = getResetTime();
		const newData: StoredLimitsData = {
			count: 0,
			resetTime: newResetTime.toISOString(),
		};
		localStorage.setItem(storageKey, JSON.stringify(newData));

		return {
			remainingRequests: FREE_DAILY_LIMIT,
			resetTime: newResetTime,
			isLimitExhausted: false,
		};
	}, [isPremium, getStoredData, getResetTime, storageKey]);

	const [limits, setLimits] = useState<RequestLimitsState>(initializeLimits);

	// Re-initialize when premium status changes
	useEffect(() => {
		setLimits(initializeLimits());
	}, [isPremium, initializeLimits]);

	// Check for reset periodically
	useEffect(() => {
		if (isPremium) return;

		const interval = setInterval(() => {
			const now = new Date();
			if (limits.resetTime && now >= limits.resetTime) {
				setLimits(initializeLimits());
			}
		}, 60000); // Check every minute

		return () => clearInterval(interval);
	}, [isPremium, limits.resetTime, initializeLimits]);

	/**
	 * Use a request - decrements the counter
	 * Returns true if request was allowed, false if limit exceeded
	 */
	const useRequest = useCallback((): boolean => {
		// Premium users always get through
		if (isPremium) {
			return true;
		}

		const stored = getStoredData();
		const now = new Date();

		// Initialize if needed
		if (!stored) {
			const newResetTime = getResetTime();
			const newData: StoredLimitsData = {
				count: 1,
				resetTime: newResetTime.toISOString(),
			};
			localStorage.setItem(storageKey, JSON.stringify(newData));
			setLimits({
				remainingRequests: FREE_DAILY_LIMIT - 1,
				resetTime: newResetTime,
				isLimitExhausted: false,
			});
			return true;
		}

		const storedResetTime = new Date(stored.resetTime);

		// Reset if needed
		if (now >= storedResetTime) {
			const newResetTime = getResetTime();
			const newData: StoredLimitsData = {
				count: 1,
				resetTime: newResetTime.toISOString(),
			};
			localStorage.setItem(storageKey, JSON.stringify(newData));
			setLimits({
				remainingRequests: FREE_DAILY_LIMIT - 1,
				resetTime: newResetTime,
				isLimitExhausted: false,
			});
			return true;
		}

		// Check if limit is exceeded
		if (stored.count >= FREE_DAILY_LIMIT) {
			setLimits({
				remainingRequests: 0,
				resetTime: storedResetTime,
				isLimitExhausted: true,
			});
			return false;
		}

		// Increment counter
		const newData: StoredLimitsData = {
			count: stored.count + 1,
			resetTime: stored.resetTime,
		};
		localStorage.setItem(storageKey, JSON.stringify(newData));

		const remaining = FREE_DAILY_LIMIT - newData.count;
		setLimits({
			remainingRequests: remaining,
			resetTime: storedResetTime,
			isLimitExhausted: remaining <= 0,
		});

		return true;
	}, [isPremium, getStoredData, getResetTime, storageKey]);

	/**
	 * Check if a request can be made without using it
	 */
	const canMakeRequest = useCallback((): boolean => {
		if (isPremium) return true;
		return limits.remainingRequests > 0;
	}, [isPremium, limits.remainingRequests]);

	/**
	 * Get time until reset in human readable format
	 */
	const getTimeUntilReset = useCallback((): string => {
		if (!limits.resetTime) return "";

		const now = new Date();
		const diff = limits.resetTime.getTime() - now.getTime();

		if (diff <= 0) return "";

		const hours = Math.floor(diff / (1000 * 60 * 60));
		const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));

		if (hours > 0) {
			return `${hours}h ${minutes}m`;
		}
		return `${minutes}m`;
	}, [limits.resetTime]);

	return {
		remainingRequests: limits.remainingRequests,
		isLimitExhausted: limits.isLimitExhausted,
		resetTime: limits.resetTime,
		useRequest,
		canMakeRequest,
		getTimeUntilReset,
		isUnlimited: isPremium || limits.remainingRequests === -1,
		dailyLimit: FREE_DAILY_LIMIT,
	};
}
