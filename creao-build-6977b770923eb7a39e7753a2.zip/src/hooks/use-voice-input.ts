import { useState, useCallback, useEffect, useRef } from "react";
import { VoiceRecognitionService, VoiceRecognitionError } from "@/services/voice-service";

/**
 * Hook for voice input functionality
 */
export function useVoiceInput() {
	const [isListening, setIsListening] = useState(false);
	const [isSupported, setIsSupported] = useState(false);
	const [error, setError] = useState<string | null>(null);
	const serviceRef = useRef<VoiceRecognitionService | null>(null);

	useEffect(() => {
		setIsSupported(VoiceRecognitionService.isSupported());

		if (VoiceRecognitionService.isSupported()) {
			try {
				serviceRef.current = new VoiceRecognitionService();
			} catch (err) {
				setError(
					err instanceof Error ? err.message : "Failed to initialize voice recognition",
				);
			}
		}

		return () => {
			if (serviceRef.current) {
				serviceRef.current.stopListening();
			}
		};
	}, []);

	const startListening = useCallback(
		(onResult: (text: string) => void) => {
			if (!serviceRef.current) {
				setError("Voice recognition not available");
				return;
			}

			setError(null);
			serviceRef.current.startListening(
				(text) => {
					onResult(text);
					setIsListening(false);
				},
				(err) => {
					setError(err.message);
					setIsListening(false);
				},
			);
			setIsListening(true);
		},
		[],
	);

	const stopListening = useCallback(() => {
		if (serviceRef.current) {
			serviceRef.current.stopListening();
			setIsListening(false);
		}
	}, []);

	return {
		isListening,
		isSupported,
		error,
		startListening,
		stopListening,
	};
}
