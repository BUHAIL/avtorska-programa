import { useState, useEffect, useCallback } from "react";

/**
 * Onboarding state stored in localStorage
 */
interface OnboardingState {
	hasVisited: boolean;
	hasGeneratedRecipe: boolean;
	visitCount: number;
	lastVisit: string | null;
}

const STORAGE_KEY = "chefai_onboarding";

const DEFAULT_STATE: OnboardingState = {
	hasVisited: false,
	hasGeneratedRecipe: false,
	visitCount: 0,
	lastVisit: null,
};

/**
 * Hook to manage first-time user onboarding state
 * Persists to localStorage for cross-session memory
 */
export function useOnboarding() {
	const [state, setState] = useState<OnboardingState>(DEFAULT_STATE);
	const [isLoaded, setIsLoaded] = useState(false);

	// Load state from localStorage on mount
	useEffect(() => {
		try {
			const stored = localStorage.getItem(STORAGE_KEY);
			if (stored) {
				const parsed = JSON.parse(stored) as OnboardingState;
				setState(parsed);
			}
		} catch {
			// Ignore parse errors, use defaults
		}
		setIsLoaded(true);
	}, []);

	// Save state to localStorage when it changes
	useEffect(() => {
		if (!isLoaded) return;
		try {
			localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
		} catch {
			// Ignore storage errors
		}
	}, [state, isLoaded]);

	// Mark that user has visited the app
	const markVisited = useCallback(() => {
		setState((prev) => ({
			...prev,
			hasVisited: true,
			visitCount: prev.visitCount + 1,
			lastVisit: new Date().toISOString(),
		}));
	}, []);

	// Mark that user has generated their first recipe
	const markFirstRecipe = useCallback(() => {
		setState((prev) => ({
			...prev,
			hasGeneratedRecipe: true,
		}));
	}, []);

	// Dismiss a specific onboarding hint
	const dismissHint = useCallback((hintKey: string) => {
		setState((prev) => ({
			...prev,
			[`dismissed_${hintKey}`]: true,
		} as OnboardingState));
	}, []);

	// Check if a hint was dismissed
	const isHintDismissed = useCallback((hintKey: string): boolean => {
		return (state as unknown as Record<string, unknown>)[`dismissed_${hintKey}`] === true;
	}, [state]);

	return {
		// State
		isFirstVisit: isLoaded && !state.hasVisited,
		isFirstRecipe: isLoaded && !state.hasGeneratedRecipe,
		visitCount: state.visitCount,
		isLoaded,

		// Actions
		markVisited,
		markFirstRecipe,
		dismissHint,
		isHintDismissed,
	};
}
