/**
 * Platform detection and app store subscription management utilities
 */

export type Platform = "ios" | "android" | "web";

/**
 * Detect the current platform based on user agent
 */
export function detectPlatform(): Platform {
	const userAgent = navigator.userAgent || navigator.vendor || "";

	// Check for iOS devices
	if (/iPad|iPhone|iPod/.test(userAgent)) {
		return "ios";
	}

	// Check for Android devices
	if (/android/i.test(userAgent)) {
		return "android";
	}

	return "web";
}

/**
 * Check if the current platform is a mobile device (iOS or Android)
 */
export function isMobile(): boolean {
	const platform = detectPlatform();
	return platform === "ios" || platform === "android";
}

/**
 * Apple App Store subscription management URL
 * This opens the user's subscriptions page in the App Store
 */
const APPLE_SUBSCRIPTIONS_URL = "https://apps.apple.com/account/subscriptions";

/**
 * Google Play Store subscription management URL
 * This opens the user's subscriptions page in Google Play
 */
const GOOGLE_PLAY_SUBSCRIPTIONS_URL =
	"https://play.google.com/store/account/subscriptions";

/**
 * Open the platform-specific subscription management page
 * - iOS: Opens Apple App Store subscriptions
 * - Android: Opens Google Play Store subscriptions
 * - Web: Falls back to a generic info message or does nothing
 *
 * @returns true if the link was opened, false if on unsupported platform
 */
export function openSubscriptionManagement(): boolean {
	const platform = detectPlatform();

	switch (platform) {
		case "ios":
			window.open(APPLE_SUBSCRIPTIONS_URL, "_blank");
			return true;
		case "android":
			window.open(GOOGLE_PLAY_SUBSCRIPTIONS_URL, "_blank");
			return true;
		default:
			// On web, we can still try to open Google Play as a fallback
			// since users might be managing from a desktop browser
			window.open(GOOGLE_PLAY_SUBSCRIPTIONS_URL, "_blank");
			return true;
	}
}

/**
 * Get the subscription management URL for the current platform
 */
export function getSubscriptionManagementUrl(): string {
	const platform = detectPlatform();

	switch (platform) {
		case "ios":
			return APPLE_SUBSCRIPTIONS_URL;
		case "android":
			return GOOGLE_PLAY_SUBSCRIPTIONS_URL;
		default:
			return GOOGLE_PLAY_SUBSCRIPTIONS_URL;
	}
}

/**
 * Get a human-readable name for the current app store
 */
export function getAppStoreName(): string {
	const platform = detectPlatform();

	switch (platform) {
		case "ios":
			return "App Store";
		case "android":
			return "Google Play";
		default:
			return "App Store";
	}
}
