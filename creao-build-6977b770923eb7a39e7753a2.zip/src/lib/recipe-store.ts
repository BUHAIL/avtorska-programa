import type { Recipe } from "@/types/recipe";

/**
 * Simple in-memory store for generated recipes
 * In a real app, this could use localStorage or a database
 */
class RecipeStore {
	private recipes: Map<string, Recipe> = new Map();

	setRecipes(recipes: Recipe[]) {
		recipes.forEach((recipe) => {
			this.recipes.set(recipe.id, recipe);
		});
	}

	getRecipe(id: string): Recipe | undefined {
		return this.recipes.get(id);
	}

	clear() {
		this.recipes.clear();
	}
}

export const recipeStore = new RecipeStore();
