import type { Theme, ThemeInfo } from "@/types/recipe";

export const AVAILABLE_THEMES: ThemeInfo[] = [
	{ id: "default", name: "Default Light", premium: false },
	{ id: "dark", name: "Dark Mode", premium: true },
	{ id: "ocean", name: "Ocean Blue", premium: true },
	{ id: "sunset", name: "Sunset Orange", premium: true },
	{ id: "forest", name: "Forest Green", premium: true },
];

export function getThemeClasses(theme: Theme): string {
	switch (theme) {
		case "dark":
			return "theme-dark";
		case "ocean":
			return "theme-ocean";
		case "sunset":
			return "theme-sunset";
		case "forest":
			return "theme-forest";
		default:
			return "";
	}
}
