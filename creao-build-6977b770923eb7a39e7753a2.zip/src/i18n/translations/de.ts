import type { Translations } from "../types";

export const de: Translations = {
	app: {
		name: "ChefAI",
		tagline: "Dein persönlicher Kochassistent",
		trustBadge: "Von Hobbyköchen vertraut",
	},

	nav: {
		backToHome: "Zurück",
		backToResults: "Zurück zu Rezepten",
		settings: "Einstellungen",
		premium: "Premium",
		history: "Verlauf",
	},

	home: {
		title: "Was ist in deinem Kühlschrank?",
		subtitle: "Sag mir was du hast, und ich zaubere etwas Leckeres!",
		inputPlaceholder: "z.B. Hähnchen, Reis, Brokkoli, Knoblauch...",
		inputHelper: "Trenne Zutaten mit Kommas oder neuen Zeilen",
		voiceInputStart: "Zutaten sprechen",
		voiceInputListening: "Ich höre...",
		voiceInputHint: "Tippe auf das Mikrofon, um Zutaten zu sprechen",
		generateButton: "Rezepte Finden",
		inspirationHint: "Nicht sicher? Probiere eines davon:",
		examples: {
			chickenRice: "Hähnchen & Reis",
			pastaTomatoes: "Pasta & Tomaten",
			eggsCheese: "Eier & Käse",
		},
		features: {
			smartAI: {
				title: "Intelligente Vorschläge",
				description: "Rezepte passend zu deinen Zutaten",
			},
			variations: {
				title: "Schnell bis Festlich",
				description: "15-Min-Gerichte bis Wochenend-Festmahle",
			},
			yourTaste: {
				title: "Für Dich Gemacht",
				description: "Respektiert deine Diät & Vorlieben",
			},
		},
		emptyState: {
			title: "Bereit wenn du es bist!",
			description: "Gib oben deine Zutaten ein oder tippe auf das Mikrofon",
			voiceHint: "Versuche zu sagen: Hähnchen, Knoblauch, Zitrone",
		},
	},

	results: {
		title: "Das kannst du kochen!",
		subtitle: "Ich habe {count} leckere {recipes} für dich gefunden. Was klingt gut?",
		loading: {
			title: "Koche Ideen...",
			description: "Finde die perfekten Rezepte für deine Zutaten",
			tips: [
				"Prüfe was du machen kannst...",
				"Finde die besten Kombinationen...",
				"Fast fertig zum Kochen!",
			],
		},
		recipeCount: "{count} Rezepte",
		tapToView: "Tippe für das vollständige Rezept",
		ingredients: "{count} Zutaten",
		minutes: "{count} Min",
		tryAgain: "Nochmal versuchen",
		newSearch: "Neue Suche",
	},

	recipe: {
		ingredients: "Was du brauchst",
		instructions: "Los geht's!",
		chefTip: {
			title: "Schneller Tipp",
			description: "Probiere beim Kochen und passe nach deinem Geschmack an. Kochen ist persönlich - mach es zu deinem!",
		},
		notFound: "Hmm, dieses Rezept scheint verschwunden zu sein. Lass uns etwas anderes finden!",
		goToHome: "Neu starten",
		enjoyMeal: "Guten Appetit!",
	},

	preferences: {
		title: "Deine Einstellungen",
		subtitle: "Hilf mir genau das zu kochen, was du liebst",
		language: {
			title: "Sprache",
			description: "Wähle deine Sprache für App und Rezepte",
		},
		dietary: {
			title: "Ernährungsbedürfnisse",
			description: "Gibt es Einschränkungen, die ich kennen sollte?",
			placeholder: "vegetarisch, vegan, glutenfrei...",
			tags: ["vegetarisch", "vegan", "glutenfrei", "laktosefrei", "keto", "paleo"],
		},
		disliked: {
			title: "Mag ich nicht",
			description: "Zutaten, die du lieber meidest",
			placeholder: "Pilze, Koriander, Sardellen...",
		},
		health: {
			title: "Gesundheitsziele",
			description: "Worauf optimierst du?",
			placeholder: "kalorienarm, proteinreich, kohlenhydratarm...",
			tags: ["kalorienarm", "proteinreich", "kohlenhydratarm", "herzgesund", "ausgewogen"],
		},
		cuisines: {
			title: "Lieblingsküchen",
			description: "Welche Geschmäcker machen dich glücklich?",
			placeholder: "italienisch, asiatisch, mexikanisch...",
			tags: ["italienisch", "asiatisch", "mexikanisch", "mediterran", "amerikanisch", "indisch"],
		},
		saveButton: "Einstellungen Speichern",
		saving: "Speichern...",
		saved: "Gespeichert!",
	},

	premium: {
		title: "Upgrade Deine Küche",
		subtitle: "Mehr Funktionen, keine Unterbrechungen",
		badge: "Am Beliebtesten",
		alreadyPremium: {
			title: "Alles bereit!",
			description: "Danke für deine Unterstützung von ChefAI. Genieße alle Premium-Vorteile!",
		},
		price: "3,99€",
		perMonth: "/Monat",
		cancelAnytime: "Jederzeit kündbar • Keine Bindung",
		features: {
			adFree: "Keine Werbung, nie",
			unlimited: "Unbegrenzte Rezeptideen",
			themes: "Schöne Premium-Themes",
			priority: "Schnellere Rezeptgenerierung",
			favorites: "Favoriten speichern",
			filters: "Extra Ernährungsoptionen",
		},
		upgradeButton: "Premium Freischalten",
		upgrading: "Freischalten...",
		demoNote: "Demo-Modus • Kostenlos testen",
		whyPremium: {
			title: "Warum Premium?",
			description1: "Schließe dich Hobbyköchen an, die ihre Küche mit unbegrenzter KI-Inspiration verbessert haben.",
			description2: "Deine Unterstützung hilft uns, ChefAI jeden Monat mit neuen Funktionen zu verbessern.",
		},
		guarantee: "Gefällt dir oder Geld zurück",
		manageSubscription: "Abo verwalten",
		manageSubscriptionDescription: "Verwalte oder kündige dein Abo in den App-Store-Einstellungen",
	},

	ads: {
		sponsored: "Gesponsert",
		adSpace: "Werbefläche",
		adFreeWithPremium: "Werbung entfernen mit Premium",
	},

	categories: {
		fast: "Schnell",
		medium: "Mittel",
		regular: "Gemütlich",
	},

	difficulty: {
		easy: "Einfach",
		medium: "Mittel",
		hard: "Fortgeschritten",
	},

	errors: {
		enterIngredient: "Füge mindestens eine Zutat hinzu, um zu starten",
		tooManyIngredients: "Lass uns bei 20 Zutaten bleiben",
		invalidIngredients: "Hmm, ich konnte diese Zutaten nicht verstehen",
		generationFailed: "Etwas ist schiefgelaufen. Versuchen wir es nochmal!",
		apiError: "Wir haben ein kleines Problem. Gleich nochmal versuchen?",
		rateLimited: "Hey, langsamer! Gib mir eine Sekunde.",
		parseError: "Ich war etwas verwirrt. Nochmal versuchen?",
		genericError: "Ups! Etwas hat nicht funktioniert. Versuchen wir es nochmal.",
	},

	onboarding: {
		welcome: {
			title: "Willkommen bei ChefAI!",
			description: "Sag mir welche Zutaten du hast — ich übernehme das Denken.",
			dismiss: "Verstanden",
		},
		hints: {
			ingredients: "Liste einfach auf, was in deinem Kühlschrank ist",
			voice: "Du kannst tippen oder sprechen",
			examples: "Tippe auf ein Beispiel zum Ausprobieren!",
		},
		firstSuccess: {
			title: "Super! Du hast gerade Zutaten in ein Gericht verwandelt!",
			subtitle: "Wähle ein Rezept, das dir gefällt",
		},
		returnTips: {
			preferences: "Nächstes Mal, versuche deine Vorlieben hinzuzufügen",
			voice: "Tipp: Nutze Spracheingabe beim Kochen",
		},
	},

	limits: {
		remaining: "{count} Rezepte heute übrig",
		exhausted: {
			title: "Tageslimit erreicht",
			description: "Du hast alle kostenlosen Rezepte für heute verbraucht.",
			resetIn: "Neue Rezepte verfügbar in {time}",
		},
		upgradePrompt: "Upgrade zu Pro für unbegrenzte Rezepte",
	},

	history: {
		title: "Rezeptverlauf",
		subtitle: "Deine zuvor generierten Rezepte",
		empty: {
			title: "Noch keine Rezepte",
			description: "Deine generierten Rezepte erscheinen hier",
		},
		proOnly: {
			title: "Pro-Funktion",
			description: "Upgrade zu Pro, um deinen Rezeptverlauf zu speichern und anzusehen",
		},
		viewRecipe: "Rezept Ansehen",
		generatedOn: "Generiert am {date}",
	},
};
