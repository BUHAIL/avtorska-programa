import { en } from "./en";
import { ru } from "./ru";
import { es } from "./es";
import { pl } from "./pl";
import { de } from "./de";
import { it } from "./it";
import { zh } from "./zh";
import { uk } from "./uk";
import type { Language, Translations } from "../types";

/**
 * All translations indexed by language code
 */
export const translations: Record<Language, Translations> = {
	en,
	ru,
	es,
	pl,
	de,
	it,
	zh,
	uk,
};

/**
 * Get translations for a specific language
 */
export function getTranslations(language: Language): Translations {
	return translations[language] || translations.en;
}
