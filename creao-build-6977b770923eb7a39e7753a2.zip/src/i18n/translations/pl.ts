import type { Translations } from "../types";

export const pl: Translations = {
	app: {
		name: "ChefAI",
		tagline: "Twój osobisty pomocnik kulinarny",
		trustBadge: "Zaufany przez domowych kucharzy",
	},

	nav: {
		backToHome: "Wróć",
		backToResults: "Wróć do przepisów",
		settings: "Ustawienia",
		premium: "Premium",
		history: "Historia",
	},

	home: {
		title: "Co masz w lodówce?",
		subtitle: "Powiedz mi co masz, a przygotuję coś pysznego!",
		inputPlaceholder: "np. kurczak, ryż, brokuły, czosnek...",
		inputHelper: "Oddziel składniki przecinkami lub nowymi liniami",
		voiceInputStart: "Powiedz składniki",
		voiceInputListening: "Słucham...",
		voiceInputHint: "Dotknij mikrofonu, aby powiedzieć składniki",
		generateButton: "Znajdź Przepisy",
		inspirationHint: "Nie wiesz? Spróbuj jednego z tych:",
		examples: {
			chickenRice: "Kurczak i ryż",
			pastaTomatoes: "Makaron i pomidory",
			eggsCheese: "Jajka i ser",
		},
		features: {
			smartAI: {
				title: "Inteligentne Sugestie",
				description: "Przepisy dopasowane do twoich składników",
			},
			variations: {
				title: "Od szybkich do wykwintnych",
				description: "Posiłki w 15 min do weekendowych uczt",
			},
			yourTaste: {
				title: "Dla Ciebie",
				description: "Szanuje twoją dietę i preferencje",
			},
		},
		emptyState: {
			title: "Gotowy, kiedy ty!",
			description: "Wpisz składniki powyżej lub dotknij mikrofonu",
			voiceHint: "Spróbuj powiedzieć: kurczak, czosnek, cytryna",
		},
	},

	results: {
		title: "Oto co możesz przygotować!",
		subtitle: "Znalazłem {count} pysznych {recipes} dla ciebie. Co ci odpowiada?",
		loading: {
			title: "Przygotowuję pomysły...",
			description: "Szukam idealnych przepisów dla twoich składników",
			tips: [
				"Sprawdzam co można przygotować...",
				"Szukam najlepszych kombinacji...",
				"Prawie gotowe!",
			],
		},
		recipeCount: "{count} przepisów",
		tapToView: "Dotknij, aby zobaczyć pełny przepis",
		ingredients: "{count} składników",
		minutes: "{count} min",
		tryAgain: "Spróbuj ponownie",
		newSearch: "Nowe wyszukiwanie",
	},

	recipe: {
		ingredients: "Czego potrzebujesz",
		instructions: "Zaczynamy gotować!",
		chefTip: {
			title: "Szybka wskazówka",
			description: "Próbuj w trakcie gotowania i dostosuj do swojego gustu. Gotowanie to sztuka - zrób to po swojemu!",
		},
		notFound: "Hmm, ten przepis gdzieś zniknął. Znajdźmy coś innego!",
		goToHome: "Zacznij od nowa",
		enjoyMeal: "Smacznego!",
	},

	preferences: {
		title: "Twoje Preferencje",
		subtitle: "Pomóż mi gotować dokładnie to, co lubisz",
		language: {
			title: "Język",
			description: "Wybierz język aplikacji i przepisów",
		},
		dietary: {
			title: "Potrzeby Dietetyczne",
			description: "Jakieś ograniczenia, o których powinienem wiedzieć?",
			placeholder: "wegetariańskie, wegańskie, bezglutenowe...",
			tags: ["wegetariańskie", "wegańskie", "bezglutenowe", "bez nabiału", "keto", "paleo"],
		},
		disliked: {
			title: "Nie lubię",
			description: "Składniki, których wolisz unikać",
			placeholder: "grzyby, kolendra, anchois...",
		},
		health: {
			title: "Cele Zdrowotne",
			description: "Na czym ci zależy?",
			placeholder: "niskokaloryczne, wysokobiałkowe...",
			tags: ["niskokaloryczne", "wysokobiałkowe", "niskowęglowodanowe", "dla serca", "zrównoważone"],
		},
		cuisines: {
			title: "Ulubione Kuchnie",
			description: "Jakie smaki cię cieszą?",
			placeholder: "włoska, azjatycka, meksykańska...",
			tags: ["włoska", "azjatycka", "meksykańska", "śródziemnomorska", "amerykańska", "indyjska"],
		},
		saveButton: "Zapisz Preferencje",
		saving: "Zapisywanie...",
		saved: "Zapisano!",
	},

	premium: {
		title: "Ulepsz Swoją Kuchnię",
		subtitle: "Więcej funkcji, zero przerw",
		badge: "Najpopularniejszy",
		alreadyPremium: {
			title: "Wszystko gotowe!",
			description: "Dziękujemy za wsparcie ChefAI. Ciesz się wszystkimi funkcjami premium!",
		},
		price: "$3.99",
		perMonth: "/miesiąc",
		cancelAnytime: "Anuluj kiedy chcesz • Bez zobowiązań",
		features: {
			adFree: "Zero reklam, zawsze",
			unlimited: "Nieograniczone pomysły na przepisy",
			themes: "Piękne motywy premium",
			priority: "Szybsze generowanie przepisów",
			favorites: "Zapisz ulubione",
			filters: "Dodatkowe opcje dietetyczne",
		},
		upgradeButton: "Odblokuj Premium",
		upgrading: "Odblokowywanie...",
		demoNote: "Tryb demo • Za darmo do wypróbowania",
		whyPremium: {
			title: "Dlaczego Premium?",
			description1: "Dołącz do domowych kucharzy, którzy ulepszyli swoją kuchnię dzięki nieograniczonej inspiracji AI.",
			description2: "Twoje wsparcie pomaga nam ulepszać ChefAI nowymi funkcjami co miesiąc.",
		},
		guarantee: "Podoba się lub zwrot pieniędzy",
		manageSubscription: "Zarządzaj Subskrypcją",
		manageSubscriptionDescription: "Zarządzaj lub anuluj subskrypcję w ustawieniach sklepu z aplikacjami",
	},

	ads: {
		sponsored: "Sponsorowane",
		adSpace: "Miejsce reklamowe",
		adFreeWithPremium: "Usuń reklamy z Premium",
	},

	categories: {
		fast: "Szybki",
		medium: "Średni",
		regular: "Spokojny",
	},

	difficulty: {
		easy: "Łatwy",
		medium: "Średni",
		hard: "Zaawansowany",
	},

	errors: {
		enterIngredient: "Dodaj przynajmniej jeden składnik, aby zacząć",
		tooManyIngredients: "Ograniczmy się do 20 składników",
		invalidIngredients: "Hmm, nie zrozumiałem tych składników",
		generationFailed: "Coś poszło nie tak. Spróbujmy jeszcze raz!",
		apiError: "Mamy mały problem. Spróbuj za chwilę?",
		rateLimited: "Hej, zwolnij! Daj mi chwilę.",
		parseError: "Trochę się pogubiłem. Spróbujemy jeszcze raz?",
		genericError: "Ups! Coś nie zadziałało. Spróbujmy ponownie.",
	},

	onboarding: {
		welcome: {
			title: "Witaj w ChefAI!",
			description: "Powiedz mi jakie masz składniki — ja wszystko przemyślę.",
			dismiss: "Rozumiem",
		},
		hints: {
			ingredients: "Po prostu wymień, co masz w lodówce",
			voice: "Możesz pisać lub mówić głosem",
			examples: "Dotknij przykładu, aby spróbować!",
		},
		firstSuccess: {
			title: "Świetnie! Właśnie zamieniłeś składniki w posiłek!",
			subtitle: "Wybierz przepis, który ci odpowiada",
		},
		returnTips: {
			preferences: "Następnym razem spróbuj dodać swoje preferencje",
			voice: "Wskazówka: użyj wprowadzania głosowego podczas gotowania",
		},
	},

	limits: {
		remaining: "Pozostało {count} przepisów dziś",
		exhausted: {
			title: "Dzienny limit osiągnięty",
			description: "Wykorzystałeś wszystkie darmowe przepisy na dziś.",
			resetIn: "Nowe przepisy dostępne za {time}",
		},
		upgradePrompt: "Ulepsz do Pro dla nieograniczonych przepisów",
	},

	history: {
		title: "Historia Przepisów",
		subtitle: "Twoje wcześniej wygenerowane przepisy",
		empty: {
			title: "Brak przepisów",
			description: "Twoje wygenerowane przepisy pojawią się tutaj",
		},
		proOnly: {
			title: "Funkcja Pro",
			description: "Ulepsz do Pro, aby zapisywać i przeglądać historię przepisów",
		},
		viewRecipe: "Zobacz Przepis",
		generatedOn: "Wygenerowano {date}",
	},
};
