import type { Translations } from "../types";

export const it: Translations = {
	app: {
		name: "ChefAI",
		tagline: "Il tuo assistente culinario personale",
		trustBadge: "Scelto dai cuochi di casa",
	},

	nav: {
		backToHome: "Indietro",
		backToResults: "Torna alle ricette",
		settings: "Impostazioni",
		premium: "Premium",
		history: "Cronologia",
	},

	home: {
		title: "Cosa c'è nel tuo frigo?",
		subtitle: "Dimmi cosa hai e preparerò qualcosa di delizioso!",
		inputPlaceholder: "es. pollo, riso, broccoli, aglio...",
		inputHelper: "Separa gli ingredienti con virgole o a capo",
		voiceInputStart: "Pronuncia ingredienti",
		voiceInputListening: "Sto ascoltando...",
		voiceInputHint: "Tocca il microfono per pronunciare gli ingredienti",
		generateButton: "Trova Ricette",
		inspirationHint: "Non sei sicuro? Prova uno di questi:",
		examples: {
			chickenRice: "Pollo e riso",
			pastaTomatoes: "Pasta e pomodori",
			eggsCheese: "Uova e formaggio",
		},
		features: {
			smartAI: {
				title: "Suggerimenti Intelligenti",
				description: "Ricette abbinate ai tuoi ingredienti",
			},
			variations: {
				title: "Da veloce a raffinato",
				description: "Pasti da 15 min a banchetti del weekend",
			},
			yourTaste: {
				title: "Fatto per Te",
				description: "Rispetta la tua dieta e preferenze",
			},
		},
		emptyState: {
			title: "Pronto quando lo sei tu!",
			description: "Scrivi i tuoi ingredienti sopra o tocca il microfono",
			voiceHint: "Prova a dire: pollo, aglio, limone",
		},
	},

	results: {
		title: "Ecco cosa puoi preparare!",
		subtitle: "Ho trovato {count} {recipes} deliziose per te. Quale ti ispira?",
		loading: {
			title: "Preparo le idee...",
			description: "Cerco le ricette perfette per i tuoi ingredienti",
			tips: [
				"Controllo cosa puoi fare...",
				"Trovo le migliori combinazioni...",
				"Quasi pronto a cucinare!",
			],
		},
		recipeCount: "{count} ricette",
		tapToView: "Tocca per la ricetta completa",
		ingredients: "{count} ingredienti",
		minutes: "{count} min",
		tryAgain: "Riprova",
		newSearch: "Nuova Ricerca",
	},

	recipe: {
		ingredients: "Cosa ti serve",
		instructions: "Iniziamo a cucinare!",
		chefTip: {
			title: "Consiglio veloce",
			description: "Assaggia mentre cucini e regola a tuo gusto. La cucina è personale - falla tua!",
		},
		notFound: "Hmm, questa ricetta sembra essere scomparsa. Troviamo qualcos'altro!",
		goToHome: "Ricomincia",
		enjoyMeal: "Buon appetito!",
	},

	preferences: {
		title: "Le Tue Preferenze",
		subtitle: "Aiutami a cucinare esattamente ciò che ami",
		language: {
			title: "Lingua",
			description: "Scegli la lingua per l'app e le ricette",
		},
		dietary: {
			title: "Esigenze Alimentari",
			description: "Restrizioni che dovrei conoscere?",
			placeholder: "vegetariano, vegano, senza glutine...",
			tags: ["vegetariano", "vegano", "senza glutine", "senza lattosio", "keto", "paleo"],
		},
		disliked: {
			title: "Non Mi Piace",
			description: "Ingredienti che preferisci evitare",
			placeholder: "funghi, coriandolo, acciughe...",
		},
		health: {
			title: "Obiettivi di Salute",
			description: "Per cosa stai ottimizzando?",
			placeholder: "ipocalorico, iperproteico, low carb...",
			tags: ["ipocalorico", "iperproteico", "low carb", "salutare", "bilanciato"],
		},
		cuisines: {
			title: "Cucine Preferite",
			description: "Quali sapori ti rendono felice?",
			placeholder: "italiana, asiatica, messicana...",
			tags: ["italiana", "asiatica", "messicana", "mediterranea", "americana", "indiana"],
		},
		saveButton: "Salva Preferenze",
		saving: "Salvataggio...",
		saved: "Salvato!",
	},

	premium: {
		title: "Migliora la Tua Cucina",
		subtitle: "Più funzionalità, zero interruzioni",
		badge: "Più Popolare",
		alreadyPremium: {
			title: "Tutto pronto!",
			description: "Grazie per supportare ChefAI. Goditi tutti i vantaggi premium!",
		},
		price: "€3,99",
		perMonth: "/mese",
		cancelAnytime: "Annulla quando vuoi • Senza impegno",
		features: {
			adFree: "Zero pubblicità, mai",
			unlimited: "Idee ricette illimitate",
			themes: "Bellissimi temi premium",
			priority: "Generazione più veloce",
			favorites: "Salva i preferiti",
			filters: "Opzioni dietetiche extra",
		},
		upgradeButton: "Sblocca Premium",
		upgrading: "Sblocco...",
		demoNote: "Modalità demo • Prova gratis",
		whyPremium: {
			title: "Perché Premium?",
			description1: "Unisciti ai cuochi casalinghi che hanno migliorato la loro cucina con ispirazione AI illimitata.",
			description2: "Il tuo supporto ci aiuta a migliorare ChefAI con nuove funzionalità ogni mese.",
		},
		guarantee: "Ti piace o rimborso garantito",
		manageSubscription: "Gestisci Abbonamento",
		manageSubscriptionDescription: "Gestisci o annulla il tuo abbonamento nelle impostazioni dell'app store",
	},

	ads: {
		sponsored: "Sponsorizzato",
		adSpace: "Spazio pubblicitario",
		adFreeWithPremium: "Rimuovi pubblicità con Premium",
	},

	categories: {
		fast: "Veloce",
		medium: "Medio",
		regular: "Rilassato",
	},

	difficulty: {
		easy: "Facile",
		medium: "Medio",
		hard: "Avanzato",
	},

	errors: {
		enterIngredient: "Aggiungi almeno un ingrediente per iniziare",
		tooManyIngredients: "Limitiamoci a 20 ingredienti",
		invalidIngredients: "Hmm, non ho capito questi ingredienti",
		generationFailed: "Qualcosa è andato storto. Riproviamo!",
		apiError: "Abbiamo un piccolo problema. Riprovi tra un momento?",
		rateLimited: "Ehi, rallenta! Dammi un secondo.",
		parseError: "Mi sono confuso. Riproviamo?",
		genericError: "Ops! Qualcosa non ha funzionato. Riproviamo.",
	},

	onboarding: {
		welcome: {
			title: "Benvenuto in ChefAI!",
			description: "Dimmi quali ingredienti hai — penso a tutto io.",
			dismiss: "Capito",
		},
		hints: {
			ingredients: "Elenca semplicemente cosa hai nel frigo",
			voice: "Puoi scrivere o usare la voce",
			examples: "Tocca un esempio per provarlo!",
		},
		firstSuccess: {
			title: "Fantastico! Hai appena trasformato ingredienti in un pasto!",
			subtitle: "Scegli la ricetta che ti ispira",
		},
		returnTips: {
			preferences: "La prossima volta, prova ad aggiungere le tue preferenze",
			voice: "Consiglio: usa l'input vocale mentre cucini",
		},
	},

	limits: {
		remaining: "{count} ricette rimaste oggi",
		exhausted: {
			title: "Limite giornaliero raggiunto",
			description: "Hai usato tutte le ricette gratuite di oggi.",
			resetIn: "Nuove ricette disponibili tra {time}",
		},
		upgradePrompt: "Passa a Pro per ricette illimitate",
	},

	history: {
		title: "Cronologia Ricette",
		subtitle: "Le tue ricette generate in precedenza",
		empty: {
			title: "Nessuna ricetta ancora",
			description: "Le tue ricette generate appariranno qui",
		},
		proOnly: {
			title: "Funzione Pro",
			description: "Passa a Pro per salvare e visualizzare la cronologia delle ricette",
		},
		viewRecipe: "Vedi Ricetta",
		generatedOn: "Generato il {date}",
	},
};
