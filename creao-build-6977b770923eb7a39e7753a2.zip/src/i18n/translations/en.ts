import type { Translations } from "../types";

export const en: Translations = {
	app: {
		name: "ChefAI",
		tagline: "Your personal cooking companion",
		trustBadge: "Trusted by home cooks everywhere",
	},

	nav: {
		backToHome: "Back",
		backToResults: "Back to recipes",
		settings: "Preferences",
		premium: "Go Premium",
		history: "History",
	},

	home: {
		title: "What's in your fridge?",
		subtitle: "Just tell me what you have, and I'll whip up something delicious!",
		inputPlaceholder: "e.g. chicken, rice, broccoli, garlic...",
		inputHelper: "Separate ingredients with commas or new lines",
		voiceInputStart: "Speak ingredients",
		voiceInputListening: "I'm listening...",
		voiceInputHint: "Tap the mic to speak your ingredients",
		generateButton: "Find Recipes",
		inspirationHint: "Not sure? Try one of these:",
		examples: {
			chickenRice: "Chicken & Rice",
			pastaTomatoes: "Pasta & Tomatoes",
			eggsCheese: "Eggs & Cheese",
		},
		features: {
			smartAI: {
				title: "Smart Suggestions",
				description: "Recipes matched to your ingredients",
			},
			variations: {
				title: "Quick to Fancy",
				description: "15-min meals to weekend feasts",
			},
			yourTaste: {
				title: "Made for You",
				description: "Respects your diet & preferences",
			},
		},
		emptyState: {
			title: "Ready when you are!",
			description: "Type your ingredients above or tap the mic to get started",
			voiceHint: "Try saying: chicken, garlic, lemon",
		},
	},

	results: {
		title: "Here's what you can make!",
		subtitle: "I found {count} delicious {recipes} for you. Which one sounds good?",
		loading: {
			title: "Cooking up ideas...",
			description: "Finding the perfect recipes for your ingredients",
			tips: [
				"Checking what you can make...",
				"Finding the best combinations...",
				"Almost ready to cook!",
			],
		},
		recipeCount: "{count} recipes",
		tapToView: "Tap for the full recipe",
		ingredients: "{count} items",
		minutes: "{count} min",
		tryAgain: "Try Again",
		newSearch: "New Search",
	},

	recipe: {
		ingredients: "What you'll need",
		instructions: "Let's cook!",
		chefTip: {
			title: "Quick tip",
			description: "Taste as you go and adjust to your liking. Cooking is personal - make it your own!",
		},
		notFound: "Hmm, this recipe seems to have wandered off. Let's find you something else!",
		goToHome: "Start Fresh",
		enjoyMeal: "Enjoy your meal!",
	},

	preferences: {
		title: "Your Preferences",
		subtitle: "Help me cook exactly what you love",
		language: {
			title: "Language",
			description: "Choose your language for the app and recipes",
		},
		dietary: {
			title: "Dietary Needs",
			description: "Any restrictions I should know about?",
			placeholder: "vegetarian, vegan, gluten-free...",
			tags: ["vegetarian", "vegan", "gluten-free", "dairy-free", "keto", "paleo"],
		},
		disliked: {
			title: "Not a Fan Of",
			description: "Ingredients you'd rather skip",
			placeholder: "mushrooms, cilantro, anchovies...",
		},
		health: {
			title: "Health Goals",
			description: "What are you optimizing for?",
			placeholder: "low calorie, high protein, low carb...",
			tags: ["low calorie", "high protein", "low carb", "heart healthy", "balanced"],
		},
		cuisines: {
			title: "Favorite Cuisines",
			description: "What flavors make you happy?",
			placeholder: "Italian, Asian, Mexican...",
			tags: ["Italian", "Asian", "Mexican", "Mediterranean", "American", "Indian"],
		},
		saveButton: "Save Preferences",
		saving: "Saving...",
		saved: "Saved!",
	},

	premium: {
		title: "Upgrade Your Kitchen",
		subtitle: "More features, zero interruptions",
		badge: "Most Popular",
		alreadyPremium: {
			title: "You're all set!",
			description: "Thanks for supporting ChefAI. Enjoy all the premium goodness!",
		},
		price: "$3.99",
		perMonth: "/month",
		cancelAnytime: "Cancel anytime • No strings attached",
		features: {
			adFree: "Zero ads, ever",
			unlimited: "Unlimited recipe ideas",
			themes: "Beautiful premium themes",
			priority: "Faster recipe generation",
			favorites: "Save your favorites",
			filters: "Extra dietary options",
		},
		upgradeButton: "Unlock Premium",
		upgrading: "Unlocking...",
		demoNote: "Demo mode • Free to try",
		whyPremium: {
			title: "Why Premium?",
			description1: "Join home cooks who've leveled up their kitchen game with unlimited AI-powered inspiration.",
			description2: "Your support helps us keep improving ChefAI with new features every month.",
		},
		guarantee: "Love it or your money back",
		manageSubscription: "Manage Subscription",
		manageSubscriptionDescription: "Manage or cancel your subscription in your device's app store settings",
	},

	ads: {
		sponsored: "Sponsored",
		adSpace: "Ad space",
		adFreeWithPremium: "Remove ads with Premium",
	},

	categories: {
		fast: "Quick",
		medium: "Medium",
		regular: "Leisurely",
	},

	difficulty: {
		easy: "Easy",
		medium: "Medium",
		hard: "Advanced",
	},

	errors: {
		enterIngredient: "Add at least one ingredient to get started",
		tooManyIngredients: "Let's keep it under 20 ingredients",
		invalidIngredients: "Hmm, I couldn't understand those ingredients",
		generationFailed: "Something went wrong. Let's try that again!",
		apiError: "We're having a small hiccup. Try again in a moment?",
		rateLimited: "Whoa, slow down! Give me a second to catch up.",
		parseError: "I got confused there. Mind trying again?",
		genericError: "Oops! Something didn't work. Let's give it another go.",
	},

	onboarding: {
		welcome: {
			title: "Welcome to ChefAI!",
			description: "Tell me what ingredients you have — I'll do the thinking.",
			dismiss: "Got it",
		},
		hints: {
			ingredients: "Just list what's in your fridge",
			voice: "You can type or use your voice",
			examples: "Tap an example to try it out!",
		},
		firstSuccess: {
			title: "Nice! You just turned ingredients into a meal!",
			subtitle: "Pick a recipe that sounds good to you",
		},
		returnTips: {
			preferences: "Next time, try adding your dietary preferences",
			voice: "Pro tip: Use voice input for hands-free cooking",
		},
	},

	limits: {
		remaining: "{count} recipes left today",
		exhausted: {
			title: "Daily limit reached",
			description: "You've used all your free recipes for today.",
			resetIn: "New recipes available in {time}",
		},
		upgradePrompt: "Upgrade to Pro for unlimited recipes",
	},

	history: {
		title: "Recipe History",
		subtitle: "Your previously generated recipes",
		empty: {
			title: "No recipes yet",
			description: "Your generated recipes will appear here",
		},
		proOnly: {
			title: "Pro Feature",
			description: "Upgrade to Pro to save and view your recipe history",
		},
		viewRecipe: "View Recipe",
		generatedOn: "Generated on {date}",
	},
};
