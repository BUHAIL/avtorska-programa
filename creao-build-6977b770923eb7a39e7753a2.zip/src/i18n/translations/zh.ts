import type { Translations } from "../types";

export const zh: Translations = {
	app: {
		name: "ChefAI",
		tagline: "您的私人烹饪助手",
		trustBadge: "深受家庭厨师信赖",
	},

	nav: {
		backToHome: "返回",
		backToResults: "返回食谱",
		settings: "设置",
		premium: "高级版",
		history: "历史",
	},

	home: {
		title: "冰箱里有什么？",
		subtitle: "告诉我你有什么食材，我来为你创造美味！",
		inputPlaceholder: "例如：鸡肉、米饭、西兰花、大蒜...",
		inputHelper: "用逗号或换行分隔食材",
		voiceInputStart: "语音输入",
		voiceInputListening: "正在听...",
		voiceInputHint: "点击麦克风说出你的食材",
		generateButton: "查找食谱",
		inspirationHint: "不确定？试试这些：",
		examples: {
			chickenRice: "鸡肉和米饭",
			pastaTomatoes: "意面和番茄",
			eggsCheese: "鸡蛋和奶酪",
		},
		features: {
			smartAI: {
				title: "智能建议",
				description: "根据你的食材匹配食谱",
			},
			variations: {
				title: "从快手菜到大餐",
				description: "15分钟快餐到周末盛宴",
			},
			yourTaste: {
				title: "为你定制",
				description: "尊重你的饮食偏好",
			},
		},
		emptyState: {
			title: "准备就绪！",
			description: "在上方输入食材或点击麦克风开始",
			voiceHint: "试着说：鸡肉、大蒜、柠檬",
		},
	},

	results: {
		title: "看看你能做什么！",
		subtitle: "我为你找到了 {count} 道美味{recipes}。哪道听起来不错？",
		loading: {
			title: "正在构思创意...",
			description: "为你的食材寻找完美食谱",
			tips: [
				"检查可以做什么...",
				"寻找最佳搭配...",
				"马上就好！",
			],
		},
		recipeCount: "{count} 道食谱",
		tapToView: "点击查看完整食谱",
		ingredients: "{count} 种食材",
		minutes: "{count} 分钟",
		tryAgain: "重试",
		newSearch: "新搜索",
	},

	recipe: {
		ingredients: "所需食材",
		instructions: "开始烹饪！",
		chefTip: {
			title: "小贴士",
			description: "烹饪时边尝边调整。烹饪是个人的艺术——做出你自己的风格！",
		},
		notFound: "嗯，这道食谱好像不见了。让我们找点别的！",
		goToHome: "重新开始",
		enjoyMeal: "祝您用餐愉快！",
	},

	preferences: {
		title: "你的偏好",
		subtitle: "帮助我烹饪你喜欢的",
		language: {
			title: "语言",
			description: "选择应用和食谱的语言",
		},
		dietary: {
			title: "饮食需求",
			description: "有什么限制我应该知道吗？",
			placeholder: "素食、纯素、无麸质...",
			tags: ["素食", "纯素", "无麸质", "无乳制品", "生酮", "原始饮食"],
		},
		disliked: {
			title: "不喜欢的",
			description: "你想避免的食材",
			placeholder: "蘑菇、香菜、凤尾鱼...",
		},
		health: {
			title: "健康目标",
			description: "你在优化什么？",
			placeholder: "低卡、高蛋白、低碳水...",
			tags: ["低卡", "高蛋白", "低碳水", "心脏健康", "均衡"],
		},
		cuisines: {
			title: "喜欢的菜系",
			description: "什么口味让你开心？",
			placeholder: "意大利菜、亚洲菜、墨西哥菜...",
			tags: ["意大利菜", "亚洲菜", "墨西哥菜", "地中海菜", "美式", "印度菜"],
		},
		saveButton: "保存偏好",
		saving: "保存中...",
		saved: "已保存！",
	},

	premium: {
		title: "升级你的厨房",
		subtitle: "更多功能，零打扰",
		badge: "最受欢迎",
		alreadyPremium: {
			title: "一切就绪！",
			description: "感谢支持 ChefAI。享受所有高级功能吧！",
		},
		price: "¥28",
		perMonth: "/月",
		cancelAnytime: "随时取消 • 无附加条件",
		features: {
			adFree: "永无广告",
			unlimited: "无限食谱创意",
			themes: "精美高级主题",
			priority: "更快的食谱生成",
			favorites: "保存收藏",
			filters: "额外饮食选项",
		},
		upgradeButton: "解锁高级版",
		upgrading: "解锁中...",
		demoNote: "演示模式 • 免费试用",
		whyPremium: {
			title: "为什么选择高级版？",
			description1: "加入那些用无限AI灵感升级厨房的家庭厨师。",
			description2: "您的支持帮助我们每月为ChefAI添加新功能。",
		},
		guarantee: "满意保证，否则退款",
		manageSubscription: "管理订阅",
		manageSubscriptionDescription: "在设备的应用商店设置中管理或取消订阅",
	},

	ads: {
		sponsored: "赞助",
		adSpace: "广告位",
		adFreeWithPremium: "升级高级版去除广告",
	},

	categories: {
		fast: "快手",
		medium: "中等",
		regular: "悠闲",
	},

	difficulty: {
		easy: "简单",
		medium: "中等",
		hard: "进阶",
	},

	errors: {
		enterIngredient: "请添加至少一种食材开始",
		tooManyIngredients: "让我们保持在20种食材以内",
		invalidIngredients: "嗯，我无法理解这些食材",
		generationFailed: "出了点问题。让我们再试一次！",
		apiError: "遇到了小问题。稍后再试？",
		rateLimited: "慢一点！给我一秒钟。",
		parseError: "我有点困惑。再试一次？",
		genericError: "哎呀！出了点问题。让我们再试一次。",
	},

	onboarding: {
		welcome: {
			title: "欢迎使用 ChefAI！",
			description: "告诉我你有什么食材——剩下的交给我。",
			dismiss: "知道了",
		},
		hints: {
			ingredients: "只需列出冰箱里有什么",
			voice: "你可以打字或语音输入",
			examples: "点击示例试试看！",
		},
		firstSuccess: {
			title: "太棒了！你刚刚把食材变成了一顿饭！",
			subtitle: "选择一道你喜欢的食谱",
		},
		returnTips: {
			preferences: "下次试着添加你的偏好设置",
			voice: "小贴士：烹饪时使用语音输入",
		},
	},

	limits: {
		remaining: "今日剩余 {count} 道食谱",
		exhausted: {
			title: "已达到每日限额",
			description: "您已使用完今天的免费食谱。",
			resetIn: "新食谱将在 {time} 后可用",
		},
		upgradePrompt: "升级到高级版获取无限食谱",
	},

	history: {
		title: "食谱历史",
		subtitle: "您之前生成的食谱",
		empty: {
			title: "还没有食谱",
			description: "您生成的食谱将显示在这里",
		},
		proOnly: {
			title: "高级功能",
			description: "升级到高级版以保存和查看食谱历史",
		},
		viewRecipe: "查看食谱",
		generatedOn: "生成于 {date}",
	},
};
