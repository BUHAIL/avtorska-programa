import type { Translations } from "../types";

export const es: Translations = {
	app: {
		name: "ChefAI",
		tagline: "Tu compañero personal de cocina",
		trustBadge: "La elección de los cocineros caseros",
	},

	nav: {
		backToHome: "Volver",
		backToResults: "Volver a recetas",
		settings: "Preferencias",
		premium: "Premium",
		history: "Historial",
	},

	home: {
		title: "¿Qué hay en tu nevera?",
		subtitle: "Solo dime qué tienes y prepararé algo delicioso!",
		inputPlaceholder: "ej. pollo, arroz, brócoli, ajo...",
		inputHelper: "Separa los ingredientes con comas o saltos de línea",
		voiceInputStart: "Dictar ingredientes",
		voiceInputListening: "Escuchando...",
		voiceInputHint: "Toca el micrófono para dictar tus ingredientes",
		generateButton: "Buscar Recetas",
		inspirationHint: "¿No estás seguro? Prueba esto:",
		examples: {
			chickenRice: "Pollo y arroz",
			pastaTomatoes: "Pasta y tomates",
			eggsCheese: "Huevos y queso",
		},
		features: {
			smartAI: {
				title: "Sugerencias Inteligentes",
				description: "Recetas adaptadas a tus ingredientes",
			},
			variations: {
				title: "De rápido a gourmet",
				description: "Comidas de 15 min a festines de fin de semana",
			},
			yourTaste: {
				title: "Hecho para ti",
				description: "Respeta tu dieta y preferencias",
			},
		},
		emptyState: {
			title: "¡Listo cuando tú lo estés!",
			description: "Escribe tus ingredientes arriba o toca el micrófono",
			voiceHint: "Prueba decir: pollo, ajo, limón",
		},
	},

	results: {
		title: "¡Mira lo que puedes preparar!",
		subtitle: "Encontré {count} {recipes} deliciosas para ti. ¿Cuál te apetece?",
		loading: {
			title: "Preparando ideas...",
			description: "Buscando las recetas perfectas para tus ingredientes",
			tips: [
				"Revisando qué puedes hacer...",
				"Encontrando las mejores combinaciones...",
				"¡Casi listo para cocinar!",
			],
		},
		recipeCount: "{count} recetas",
		tapToView: "Toca para ver la receta completa",
		ingredients: "{count} ingredientes",
		minutes: "{count} min",
		tryAgain: "Intentar de nuevo",
		newSearch: "Nueva búsqueda",
	},

	recipe: {
		ingredients: "Lo que necesitarás",
		instructions: "¡A cocinar!",
		chefTip: {
			title: "Consejo rápido",
			description: "Prueba mientras cocinas y ajusta a tu gusto. ¡La cocina es personal - hazla tuya!",
		},
		notFound: "Hmm, esta receta parece haberse escapado. ¡Busquemos otra cosa!",
		goToHome: "Empezar de nuevo",
		enjoyMeal: "¡Buen provecho!",
	},

	preferences: {
		title: "Tus Preferencias",
		subtitle: "Ayúdame a cocinar exactamente lo que te gusta",
		language: {
			title: "Idioma",
			description: "Elige el idioma para la app y las recetas",
		},
		dietary: {
			title: "Necesidades Dietéticas",
			description: "¿Alguna restricción que deba conocer?",
			placeholder: "vegetariano, vegano, sin gluten...",
			tags: ["vegetariano", "vegano", "sin gluten", "sin lácteos", "keto", "paleo"],
		},
		disliked: {
			title: "No me gusta",
			description: "Ingredientes que prefieres evitar",
			placeholder: "champiñones, cilantro, anchoas...",
		},
		health: {
			title: "Objetivos de Salud",
			description: "¿Qué estás buscando?",
			placeholder: "bajo en calorías, alto en proteínas...",
			tags: ["bajo en calorías", "alto en proteínas", "bajo en carbohidratos", "saludable", "equilibrado"],
		},
		cuisines: {
			title: "Cocinas Favoritas",
			description: "¿Qué sabores te hacen feliz?",
			placeholder: "italiana, asiática, mexicana...",
			tags: ["italiana", "asiática", "mexicana", "mediterránea", "americana", "india"],
		},
		saveButton: "Guardar Preferencias",
		saving: "Guardando...",
		saved: "¡Guardado!",
	},

	premium: {
		title: "Mejora tu Cocina",
		subtitle: "Más funciones, cero interrupciones",
		badge: "Más Popular",
		alreadyPremium: {
			title: "¡Todo listo!",
			description: "Gracias por apoyar ChefAI. ¡Disfruta de todas las ventajas premium!",
		},
		price: "$3.99",
		perMonth: "/mes",
		cancelAnytime: "Cancela cuando quieras • Sin compromiso",
		features: {
			adFree: "Sin anuncios, nunca",
			unlimited: "Ideas de recetas ilimitadas",
			themes: "Hermosos temas premium",
			priority: "Generación más rápida",
			favorites: "Guarda tus favoritos",
			filters: "Opciones dietéticas extra",
		},
		upgradeButton: "Desbloquear Premium",
		upgrading: "Desbloqueando...",
		demoNote: "Modo demo • Prueba gratis",
		whyPremium: {
			title: "¿Por qué Premium?",
			description1: "Únete a cocineros caseros que han mejorado su cocina con inspiración ilimitada de IA.",
			description2: "Tu apoyo nos ayuda a mejorar ChefAI con nuevas funciones cada mes.",
		},
		guarantee: "Te gusta o te devolvemos el dinero",
		manageSubscription: "Gestionar Suscripción",
		manageSubscriptionDescription: "Gestiona o cancela tu suscripción en la configuración de la tienda de apps",
	},

	ads: {
		sponsored: "Patrocinado",
		adSpace: "Espacio publicitario",
		adFreeWithPremium: "Elimina anuncios con Premium",
	},

	categories: {
		fast: "Rápido",
		medium: "Medio",
		regular: "Tranquilo",
	},

	difficulty: {
		easy: "Fácil",
		medium: "Medio",
		hard: "Avanzado",
	},

	errors: {
		enterIngredient: "Añade al menos un ingrediente para empezar",
		tooManyIngredients: "Limitemos a 20 ingredientes",
		invalidIngredients: "Hmm, no pude entender esos ingredientes",
		generationFailed: "Algo salió mal. ¡Intentémoslo de nuevo!",
		apiError: "Tenemos un pequeño problema. ¿Intentas en un momento?",
		rateLimited: "¡Ey, más despacio! Dame un segundo.",
		parseError: "Me confundí un poco. ¿Lo intentamos de nuevo?",
		genericError: "¡Ups! Algo no funcionó. Intentémoslo otra vez.",
	},

	onboarding: {
		welcome: {
			title: "¡Bienvenido a ChefAI!",
			description: "Dime qué ingredientes tienes — yo me encargo del resto.",
			dismiss: "Entendido",
		},
		hints: {
			ingredients: "Solo lista lo que tienes en la nevera",
			voice: "Puedes escribir o usar tu voz",
			examples: "¡Toca un ejemplo para probarlo!",
		},
		firstSuccess: {
			title: "¡Genial! Acabas de convertir ingredientes en una comida!",
			subtitle: "Elige la receta que más te guste",
		},
		returnTips: {
			preferences: "La próxima vez, prueba añadir tus preferencias",
			voice: "Consejo: usa la entrada de voz mientras cocinas",
		},
	},

	limits: {
		remaining: "{count} recetas restantes hoy",
		exhausted: {
			title: "Límite diario alcanzado",
			description: "Has usado todas tus recetas gratuitas de hoy.",
			resetIn: "Nuevas recetas disponibles en {time}",
		},
		upgradePrompt: "Mejora a Pro para recetas ilimitadas",
	},

	history: {
		title: "Historial de Recetas",
		subtitle: "Tus recetas generadas anteriormente",
		empty: {
			title: "Sin recetas aún",
			description: "Tus recetas generadas aparecerán aquí",
		},
		proOnly: {
			title: "Función Pro",
			description: "Mejora a Pro para guardar y ver tu historial de recetas",
		},
		viewRecipe: "Ver Receta",
		generatedOn: "Generado el {date}",
	},
};
