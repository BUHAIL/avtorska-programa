import { createContext, useContext, useState, useEffect, type ReactNode } from "react";
import { type Language, type Translations, DEFAULT_LANGUAGE, SUPPORTED_LANGUAGES } from "./types";
import { getTranslations } from "./translations";

/**
 * Language context value interface
 */
interface LanguageContextValue {
	language: Language;
	setLanguage: (lang: Language) => void;
	t: Translations;
}

/**
 * Language context for providing translations throughout the app
 */
const LanguageContext = createContext<LanguageContextValue | null>(null);

/**
 * Local storage key for persisting language preference
 */
const LANGUAGE_STORAGE_KEY = "chefai-language";

/**
 * Detect browser language and map to supported language
 */
function detectBrowserLanguage(): Language {
	// Get browser language (e.g., "en-US", "ru", "es-ES")
	const browserLang = navigator.language || (navigator as any).userLanguage || "";

	// Extract the base language code (e.g., "en" from "en-US")
	const baseLang = browserLang.split("-")[0].toLowerCase();

	// Check if it's a supported language
	const supported = SUPPORTED_LANGUAGES.find(lang => lang.code === baseLang);

	return supported ? supported.code : DEFAULT_LANGUAGE;
}

/**
 * Get initial language from storage or browser detection
 */
function getInitialLanguage(): Language {
	// First, check localStorage for saved preference
	try {
		const saved = localStorage.getItem(LANGUAGE_STORAGE_KEY);
		if (saved && SUPPORTED_LANGUAGES.some(lang => lang.code === saved)) {
			return saved as Language;
		}
	} catch {
		// localStorage might not be available
	}

	// Fall back to browser detection
	return detectBrowserLanguage();
}

/**
 * Language provider component
 */
export function LanguageProvider({ children }: { children: ReactNode }) {
	const [language, setLanguageState] = useState<Language>(getInitialLanguage);
	const [translations, setTranslations] = useState<Translations>(() => getTranslations(getInitialLanguage()));

	// Update translations when language changes
	useEffect(() => {
		setTranslations(getTranslations(language));
	}, [language]);

	// Save language preference and update translations
	const setLanguage = (lang: Language) => {
		setLanguageState(lang);

		// Persist to localStorage
		try {
			localStorage.setItem(LANGUAGE_STORAGE_KEY, lang);
		} catch {
			// localStorage might not be available
		}
	};

	const value: LanguageContextValue = {
		language,
		setLanguage,
		t: translations,
	};

	return (
		<LanguageContext.Provider value={value}>
			{children}
		</LanguageContext.Provider>
	);
}

/**
 * Hook to access the current language and translations
 */
export function useLanguage(): LanguageContextValue {
	const context = useContext(LanguageContext);

	if (!context) {
		throw new Error("useLanguage must be used within a LanguageProvider");
	}

	return context;
}

/**
 * Hook to get just the translations (shorthand)
 */
export function useTranslations(): Translations {
	return useLanguage().t;
}
