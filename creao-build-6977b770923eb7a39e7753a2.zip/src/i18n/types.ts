/**
 * Supported languages for the application
 */
export type Language = "en" | "ru" | "es" | "pl" | "de" | "it" | "zh" | "uk";

/**
 * Language metadata for display in settings
 */
export interface LanguageInfo {
	code: Language;
	name: string;
	nativeName: string;
	flag: string;
}

/**
 * All supported languages with their metadata
 */
export const SUPPORTED_LANGUAGES: LanguageInfo[] = [
	{ code: "en", name: "English", nativeName: "English", flag: "🇺🇸" },
	{ code: "ru", name: "Russian", nativeName: "Русский", flag: "🇷🇺" },
	{ code: "es", name: "Spanish", nativeName: "Español", flag: "🇪🇸" },
	{ code: "pl", name: "Polish", nativeName: "Polski", flag: "🇵🇱" },
	{ code: "de", name: "German", nativeName: "Deutsch", flag: "🇩🇪" },
	{ code: "it", name: "Italian", nativeName: "Italiano", flag: "🇮🇹" },
	{ code: "zh", name: "Chinese", nativeName: "中文", flag: "🇨🇳" },
	{ code: "uk", name: "Ukrainian", nativeName: "Українська", flag: "🇺🇦" },
];

/**
 * Default language fallback
 */
export const DEFAULT_LANGUAGE: Language = "en";

/**
 * Translation keys structure - all translatable strings in the app
 */
export interface Translations {
	// App-wide
	app: {
		name: string;
		tagline: string;
		trustBadge: string;
	};

	// Navigation
	nav: {
		backToHome: string;
		backToResults: string;
		settings: string;
		premium: string;
		history: string;
	};

	// Home screen
	home: {
		title: string;
		subtitle: string;
		inputPlaceholder: string;
		inputHelper: string;
		voiceInputStart: string;
		voiceInputListening: string;
		voiceInputHint: string;
		generateButton: string;
		inspirationHint: string;
		examples: {
			chickenRice: string;
			pastaTomatoes: string;
			eggsCheese: string;
		};
		features: {
			smartAI: {
				title: string;
				description: string;
			};
			variations: {
				title: string;
				description: string;
			};
			yourTaste: {
				title: string;
				description: string;
			};
		};
		emptyState: {
			title: string;
			description: string;
			voiceHint: string;
		};
	};

	// Results screen
	results: {
		title: string;
		subtitle: string;
		loading: {
			title: string;
			description: string;
			tips: string[];
		};
		recipeCount: string;
		tapToView: string;
		ingredients: string;
		minutes: string;
		tryAgain: string;
		newSearch: string;
	};

	// Recipe detail screen
	recipe: {
		ingredients: string;
		instructions: string;
		chefTip: {
			title: string;
			description: string;
		};
		notFound: string;
		goToHome: string;
		enjoyMeal: string;
	};

	// Preferences screen
	preferences: {
		title: string;
		subtitle: string;
		language: {
			title: string;
			description: string;
		};
		dietary: {
			title: string;
			description: string;
			placeholder: string;
			tags: string[];
		};
		disliked: {
			title: string;
			description: string;
			placeholder: string;
		};
		health: {
			title: string;
			description: string;
			placeholder: string;
			tags: string[];
		};
		cuisines: {
			title: string;
			description: string;
			placeholder: string;
			tags: string[];
		};
		saveButton: string;
		saving: string;
		saved: string;
	};

	// Premium screen
	premium: {
		title: string;
		subtitle: string;
		badge: string;
		alreadyPremium: {
			title: string;
			description: string;
		};
		price: string;
		perMonth: string;
		cancelAnytime: string;
		features: {
			adFree: string;
			unlimited: string;
			themes: string;
			priority: string;
			favorites: string;
			filters: string;
		};
		upgradeButton: string;
		upgrading: string;
		demoNote: string;
		whyPremium: {
			title: string;
			description1: string;
			description2: string;
		};
		guarantee: string;
		manageSubscription: string;
		manageSubscriptionDescription: string;
	};

	// Ad banner
	ads: {
		sponsored: string;
		adSpace: string;
		adFreeWithPremium: string;
	};

	// Recipe categories and difficulty
	categories: {
		fast: string;
		medium: string;
		regular: string;
	};

	difficulty: {
		easy: string;
		medium: string;
		hard: string;
	};

	// Errors
	errors: {
		enterIngredient: string;
		tooManyIngredients: string;
		invalidIngredients: string;
		generationFailed: string;
		apiError: string;
		rateLimited: string;
		parseError: string;
		genericError: string;
	};

	// Onboarding & First-time UX
	onboarding: {
		welcome: {
			title: string;
			description: string;
			dismiss: string;
		};
		hints: {
			ingredients: string;
			voice: string;
			examples: string;
		};
		firstSuccess: {
			title: string;
			subtitle: string;
		};
		returnTips: {
			preferences: string;
			voice: string;
		};
	};

	// Request limits
	limits: {
		remaining: string;
		exhausted: {
			title: string;
			description: string;
			resetIn: string;
		};
		upgradePrompt: string;
	};

	// History
	history: {
		title: string;
		subtitle: string;
		empty: {
			title: string;
			description: string;
		};
		proOnly: {
			title: string;
			description: string;
		};
		viewRecipe: string;
		generatedOn: string;
	};
}
