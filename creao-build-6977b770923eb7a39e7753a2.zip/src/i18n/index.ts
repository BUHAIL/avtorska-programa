// Re-export everything from the i18n module
export { LanguageProvider, useLanguage, useTranslations } from "./context";
export { type Language, type LanguageInfo, type Translations, SUPPORTED_LANGUAGES, DEFAULT_LANGUAGE } from "./types";
export { translations, getTranslations } from "./translations";
