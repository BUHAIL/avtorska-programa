import { createFileRoute } from "@tanstack/react-router";
import { PremiumScreen } from "@/components/screens/PremiumScreen";

export const Route = createFileRoute("/premium")({
	component: PremiumScreen,
});
