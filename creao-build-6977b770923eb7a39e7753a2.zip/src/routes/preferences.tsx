import { createFileRoute } from "@tanstack/react-router";
import { PreferencesScreen } from "@/components/screens/PreferencesScreen";

export const Route = createFileRoute("/preferences")({
	component: PreferencesScreen,
});
