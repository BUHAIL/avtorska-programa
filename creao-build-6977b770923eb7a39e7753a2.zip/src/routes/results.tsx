import { createFileRoute } from "@tanstack/react-router";
import { ResultsScreen } from "@/components/screens/ResultsScreen";

export const Route = createFileRoute("/results")({
	component: ResultsScreen,
	validateSearch: (search: Record<string, unknown>) => {
		return {
			ingredients: (search.ingredients as string) || "",
		};
	},
});
