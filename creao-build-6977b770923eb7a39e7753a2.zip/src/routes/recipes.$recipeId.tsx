import { createFileRoute } from "@tanstack/react-router";
import { RecipeDetailScreen } from "@/components/screens/RecipeDetailScreen";

export const Route = createFileRoute("/recipes/$recipeId")({
	component: RecipeDetailScreen,
});
