import { getDefaultLLMProvider } from "@/services/llm/provider-factory";
import type { Recipe, UserPreferences } from "@/types/recipe";

export class RecipeGenerationError extends Error {
	constructor(message: string) {
		super(message);
		this.name = "RecipeGenerationError";
	}
}

/**
 * Generate recipes using AI based on ingredients and preferences
 * Uses the configured LLM provider (OpenAI by default)
 */
export async function generateRecipes(
	ingredients: string,
	preferences?: UserPreferences,
	language?: string,
): Promise<Recipe[]> {
	// Validate input
	if (!ingredients || ingredients.trim().length === 0) {
		throw new RecipeGenerationError("Please provide at least one ingredient");
	}

	try {
		// Get the configured LLM provider
		const llmProvider = getDefaultLLMProvider();

		// Generate recipes using the real LLM
		const recipes = await llmProvider.generateRecipes({
			ingredients,
			preferences,
			language,
		});

		if (!recipes || recipes.length === 0) {
			throw new RecipeGenerationError(
				"No recipes were generated. Please try again with different ingredients.",
			);
		}

		return recipes;
	} catch (error) {
		if (error instanceof RecipeGenerationError) {
			throw error;
		}

		// Handle specific API errors with user-friendly messages
		const errorMessage = error instanceof Error ? error.message : "Unknown error";

		if (errorMessage.includes("API key")) {
			throw new RecipeGenerationError(
				"API configuration error. Please contact support.",
			);
		}

		if (errorMessage.includes("rate limit")) {
			throw new RecipeGenerationError(
				"Too many requests. Please wait a moment and try again.",
			);
		}

		if (errorMessage.includes("parse")) {
			throw new RecipeGenerationError(
				"Failed to process the AI response. Please try again.",
			);
		}

		// Generic error
		throw new RecipeGenerationError(
			"Couldn't generate recipes right now. Please try again in a moment.",
		);
	}
}


/**
 * Validate ingredients input
 */
export function validateIngredients(ingredients: string): {
	valid: boolean;
	error?: string;
} {
	if (!ingredients || ingredients.trim().length === 0) {
		return { valid: false, error: "Please enter at least one ingredient" };
	}

	const ingredientList = ingredients
		.split(/[,\n]+/)
		.map((i) => i.trim())
		.filter(Boolean);

	if (ingredientList.length === 0) {
		return { valid: false, error: "Please enter at least one ingredient" };
	}

	if (ingredientList.length > 20) {
		return {
			valid: false,
			error: "Please limit to 20 ingredients or fewer",
		};
	}

	return { valid: true };
}
