/**
 * Voice-to-text service using browser Web Speech API
 * Abstracted to allow for future third-party service integration
 */

export interface VoiceRecognitionOptions {
	language?: string;
	continuous?: boolean;
	interimResults?: boolean;
}

export class VoiceRecognitionError extends Error {
	constructor(message: string) {
		super(message);
		this.name = "VoiceRecognitionError";
	}
}

export class VoiceRecognitionService {
	private recognition: any | null = null;
	private isListening: boolean = false;

	constructor() {
		// Check for browser support
		const SpeechRecognition =
			(window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

		if (!SpeechRecognition) {
			throw new VoiceRecognitionError(
				"Speech recognition is not supported in this browser",
			);
		}

		this.recognition = new SpeechRecognition();
	}

	/**
	 * Check if speech recognition is supported
	 */
	static isSupported(): boolean {
		return !!((window as any).SpeechRecognition || (window as any).webkitSpeechRecognition);
	}

	/**
	 * Start listening for speech
	 */
	startListening(
		onResult: (text: string) => void,
		onError?: (error: Error) => void,
		options?: VoiceRecognitionOptions,
	): void {
		if (!this.recognition) {
			const error = new VoiceRecognitionError("Speech recognition not initialized");
			onError?.(error);
			return;
		}

		if (this.isListening) {
			return;
		}

		// Configure recognition
		this.recognition.lang = options?.language || "en-US";
		this.recognition.continuous = options?.continuous || false;
		this.recognition.interimResults = options?.interimResults || false;
		this.recognition.maxAlternatives = 1;

		// Set up event handlers
		this.recognition.onresult = (event: any) => {
			const results = event.results;
			const lastResult = results[results.length - 1];

			if (lastResult.isFinal) {
				const transcript = lastResult[0].transcript;
				onResult(transcript);
			}
		};

		this.recognition.onerror = (event: any) => {
			const error = new VoiceRecognitionError(
				`Speech recognition error: ${event.error}`,
			);
			onError?.(error);
			this.isListening = false;
		};

		this.recognition.onend = () => {
			this.isListening = false;
		};

		// Start recognition
		try {
			this.recognition.start();
			this.isListening = true;
		} catch (error) {
			const recognitionError = new VoiceRecognitionError(
				error instanceof Error ? error.message : "Failed to start recognition",
			);
			onError?.(recognitionError);
		}
	}

	/**
	 * Stop listening for speech
	 */
	stopListening(): void {
		if (this.recognition && this.isListening) {
			this.recognition.stop();
			this.isListening = false;
		}
	}

	/**
	 * Get listening status
	 */
	getIsListening(): boolean {
		return this.isListening;
	}
}

// Note: Web Speech API types are handled with 'any' for browser compatibility
