/**
 * LLM Provider Factory
 * Creates and manages LLM provider instances
 * Uses CREAO platform's authenticated API - no API keys required
 */

import type { LLMProvider } from "./types";
import { CreaoOpenAIProvider } from "./creao-openai-provider";
import { LLM_CONFIG } from "@/config/llm-config";

export type ProviderType = "openai" | "anthropic" | "gemini";

/**
 * Create an LLM provider instance based on configuration
 * Uses CREAO platform API - no API keys needed
 */
export function createLLMProvider(
	type: ProviderType = "openai",
): LLMProvider {
	switch (type) {
		case "openai":
			return new CreaoOpenAIProvider({
				model: "gpt-4o",
				temperature: LLM_CONFIG.temperature,
				maxTokens: LLM_CONFIG.maxTokens,
				systemPrompt: LLM_CONFIG.systemPrompt,
			});
		case "anthropic":
			throw new Error("Anthropic provider not yet implemented");
		case "gemini":
			throw new Error("Gemini provider not yet implemented");
		default:
			throw new Error(`Unknown provider type: ${type}`);
	}
}

/**
 * Singleton instance for default provider
 */
let defaultProvider: LLMProvider | null = null;

/**
 * Get or create the default LLM provider instance
 */
export function getDefaultLLMProvider(): LLMProvider {
	if (!defaultProvider) {
		const providerType = (LLM_CONFIG.provider as ProviderType) || "openai";
		defaultProvider = createLLMProvider(providerType);
	}
	return defaultProvider;
}

/**
 * Reset the default provider (useful for testing or switching providers)
 */
export function resetDefaultProvider(): void {
	defaultProvider = null;
}
