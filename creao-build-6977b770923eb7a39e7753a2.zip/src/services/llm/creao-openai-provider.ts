/**
 * CREAO OpenAI Provider
 * Uses the CREAO platform's authenticated API to access OpenAI GPT
 * No API key required - authentication is handled by the platform
 *
 * Supports two modes:
 * - Preview Mode: Simplified prompts for reliable CREAO preview environment
 * - Production Mode: Full advanced prompts with rich formatting
 */

import type {
	LLMProvider,
	LLMMessage,
	LLMResponse,
	RecipeGenerationRequest,
} from "./types";
import type { Recipe, RecipeCategory, RecipeDifficulty } from "@/types/recipe";
import { platformApi } from "@/sdk/core/request";
import { LLM_CONFIG } from "@/config/llm-config";
import { isPreviewMode, getEnvironmentName } from "./environment";

/**
 * CREAO Platform OpenAI Provider
 * Routes requests through the authenticated CREAO platform API
 */
export class CreaoOpenAIProvider implements LLMProvider {
	private model: string;
	private temperature: number;
	private maxTokens: number;
	private systemPrompt: string;

	constructor(options?: {
		model?: string;
		temperature?: number;
		maxTokens?: number;
		systemPrompt?: string;
	}) {
		this.model = options?.model || "gpt-4o";
		this.temperature = options?.temperature ?? LLM_CONFIG.temperature;
		this.maxTokens = options?.maxTokens ?? LLM_CONFIG.maxTokens;
		this.systemPrompt = options?.systemPrompt || LLM_CONFIG.systemPrompt;
	}

	async generateCompletion(messages: LLMMessage[]): Promise<LLMResponse> {
		try {
			// Use CREAO platform API to route to OpenAI
			const response = await platformApi.post("/integration/openai/v1/chat/completions", {
				model: this.model,
				messages: messages,
				temperature: this.temperature,
				max_tokens: this.maxTokens,
			});

			if (!response.ok) {
				const errorData = await response.json().catch(() => ({ error: { message: "Unknown error" } }));
				throw new Error(
					`OpenAI API error: ${errorData.error?.message || response.statusText}`,
				);
			}

			const data = await response.json();
			const choice = data.choices?.[0];

			return {
				content: choice?.message?.content || "",
				finishReason: choice?.finish_reason,
				usage: {
					promptTokens: data.usage?.prompt_tokens || 0,
					completionTokens: data.usage?.completion_tokens || 0,
					totalTokens: data.usage?.total_tokens || 0,
				},
			};
		} catch (error) {
			if (error instanceof Error) {
				// Re-throw with more context
				throw new Error(`CREAO OpenAI request failed: ${error.message}`);
			}
			throw error;
		}
	}

	async generateRecipes(request: RecipeGenerationRequest): Promise<Recipe[]> {
		const { ingredients, preferences, language = "en" } = request;
		const previewMode = isPreviewMode();

		console.log(`[CreaoOpenAI] Generating recipes in ${getEnvironmentName()} mode`);

		// Language names for LLM instruction
		const languageNames: Record<string, string> = {
			en: "English",
			ru: "Russian",
			es: "Spanish",
		};
		const targetLanguage = languageNames[language] || "English";

		// Build messages based on mode
		const messages: LLMMessage[] = previewMode
			? this.buildPreviewModeMessages(ingredients, preferences, targetLanguage)
			: this.buildProductionModeMessages(ingredients, preferences, targetLanguage);

		const response = await this.generateCompletion(messages);

		// Parse response based on mode
		return previewMode
			? this.parsePreviewResponse(response.content)
			: this.parseProductionResponse(response.content);
	}

	/**
	 * Build simplified messages for preview mode
	 * Uses plain text response for maximum compatibility
	 */
	private buildPreviewModeMessages(
		ingredients: string,
		preferences: RecipeGenerationRequest["preferences"],
		targetLanguage: string,
	): LLMMessage[] {
		// Simple system prompt
		const systemPrompt = `You are ChefAI, a friendly cooking assistant. Generate recipes in ${targetLanguage}. Keep responses simple and clear.`;

		// Build a simple, direct prompt
		let userPrompt = `Create 3 recipes using: ${ingredients}`;

		if (preferences?.dietaryPreferences?.length) {
			userPrompt += `. Diet: ${preferences.dietaryPreferences.join(", ")}`;
		}
		if (preferences?.dislikedIngredients?.length) {
			userPrompt += `. Avoid: ${preferences.dislikedIngredients.join(", ")}`;
		}

		userPrompt += `

Reply with exactly this JSON (no markdown, no extra text):
{"recipes":[{"title":"Name","description":"Brief description","ingredients":["item 1","item 2"],"instructions":["Step 1","Step 2"],"category":"Fast","cookingTime":20,"difficulty":"Easy"},{"title":"Name2","description":"Brief description","ingredients":["item 1","item 2"],"instructions":["Step 1","Step 2"],"category":"Medium","cookingTime":45,"difficulty":"Medium"},{"title":"Name3","description":"Brief description","ingredients":["item 1","item 2"],"instructions":["Step 1","Step 2"],"category":"Regular","cookingTime":60,"difficulty":"Medium"}]}

Categories must be: Fast, Medium, or Regular
Difficulty must be: Easy, Medium, or Hard
All text in ${targetLanguage}.`;

		return [
			{ role: "system", content: systemPrompt },
			{ role: "user", content: userPrompt },
		];
	}

	/**
	 * Build full advanced messages for production mode
	 * Rich formatting with detailed instructions
	 */
	private buildProductionModeMessages(
		ingredients: string,
		preferences: RecipeGenerationRequest["preferences"],
		targetLanguage: string,
	): LLMMessage[] {
		let userPrompt = `I have these ingredients: ${ingredients}\n\n`;

		if (preferences?.dietaryPreferences?.length) {
			userPrompt += `Dietary restrictions: ${preferences.dietaryPreferences.join(", ")}\n`;
		}

		if (preferences?.dislikedIngredients?.length) {
			userPrompt += `Ingredients to avoid: ${preferences.dislikedIngredients.join(", ")}\n`;
		}

		if (preferences?.healthGoals?.length) {
			userPrompt += `Health goals: ${preferences.healthGoals.join(", ")}\n`;
		}

		if (preferences?.preferredCuisines?.length) {
			userPrompt += `Preferred cuisines: ${preferences.preferredCuisines.join(", ")}\n`;
		}

		userPrompt += `\nIMPORTANT: Generate ALL recipe content (titles, descriptions, ingredients, instructions) in ${targetLanguage}. The entire response must be in ${targetLanguage}.

Please create 3 recipe variations: one fast (under 30 min), one medium (30-60 min), and one that takes more time but is more elaborate. For each recipe, provide the response in the following JSON format:

{
  "recipes": [
    {
      "title": "Recipe Name in ${targetLanguage}",
      "description": "A brief, enticing description in ${targetLanguage}",
      "ingredients": ["ingredient 1 with amount in ${targetLanguage}", "ingredient 2 with amount in ${targetLanguage}"],
      "instructions": ["step 1 in ${targetLanguage}", "step 2 in ${targetLanguage}"],
      "category": "Fast" | "Medium" | "Regular",
      "cookingTime": number (in minutes),
      "difficulty": "Easy" | "Medium" | "Hard"
    }
  ]
}

Make the recipes practical, delicious, and use the ingredients I provided as the main components. Be friendly and encouraging in your descriptions! Remember: ALL text content must be in ${targetLanguage}.`;

		return [
			{ role: "system", content: this.systemPrompt },
			{ role: "user", content: userPrompt },
		];
	}

	/**
	 * Parse response for preview mode
	 * More lenient parsing for simpler responses
	 */
	private parsePreviewResponse(content: string): Recipe[] {
		try {
			const trimmed = content.trim();

			// Try to find JSON object in response (handle potential text wrapping)
			let jsonStr = trimmed;

			// Remove markdown code blocks if present
			const jsonMatch = trimmed.match(/```(?:json)?\s*(\{[\s\S]*\})\s*```/);
			if (jsonMatch) {
				jsonStr = jsonMatch[1];
			} else {
				// Try to extract just the JSON object
				const objectMatch = trimmed.match(/\{[\s\S]*\}/);
				if (objectMatch) {
					jsonStr = objectMatch[0];
				}
			}

			const parsed = JSON.parse(jsonStr);
			const recipesData = parsed.recipes || [];

			return recipesData.map((r: any) => ({
				id: crypto.randomUUID(),
				title: r.title || "Untitled Recipe",
				description: r.description || "A delicious recipe",
				ingredients: Array.isArray(r.ingredients) ? r.ingredients : [],
				instructions: Array.isArray(r.instructions) ? r.instructions : [],
				category: this.normalizeCategory(r.category),
				cookingTime: Number(r.cookingTime) || 30,
				difficulty: this.normalizeDifficulty(r.difficulty),
				generatedAt: new Date().toISOString(),
			}));
		} catch (error) {
			console.error("Failed to parse preview response:", error, content);
			throw new Error(
				"Failed to parse recipes. Please try again.",
			);
		}
	}

	/**
	 * Parse response for production mode
	 * Full parsing with detailed error handling
	 */
	private parseProductionResponse(content: string): Recipe[] {
		try {
			const trimmed = content.trim();
			// Extract JSON from markdown code blocks if present
			const jsonMatch = trimmed.match(/```(?:json)?\s*(\{[\s\S]*\})\s*```/) || [
				null,
				trimmed,
			];
			const jsonStr = jsonMatch[1] || trimmed;

			const parsed = JSON.parse(jsonStr);
			const recipesData = parsed.recipes || [];

			return recipesData.map((r: any) => ({
				id: crypto.randomUUID(),
				title: r.title,
				description: r.description,
				ingredients: r.ingredients,
				instructions: r.instructions,
				category: r.category as RecipeCategory,
				cookingTime: r.cookingTime,
				difficulty: r.difficulty as RecipeDifficulty,
				generatedAt: new Date().toISOString(),
			}));
		} catch (error) {
			console.error("Failed to parse recipe JSON:", error);
			throw new Error(
				"Failed to parse recipes from AI response. Please try again.",
			);
		}
	}

	/**
	 * Normalize category value to valid RecipeCategory
	 */
	private normalizeCategory(category: string): RecipeCategory {
		const normalized = String(category || "Medium").toLowerCase();
		if (normalized.includes("fast") || normalized.includes("quick")) return "Fast";
		if (normalized.includes("regular") || normalized.includes("long")) return "Regular";
		return "Medium";
	}

	/**
	 * Normalize difficulty value to valid RecipeDifficulty
	 */
	private normalizeDifficulty(difficulty: string): RecipeDifficulty {
		const normalized = String(difficulty || "Medium").toLowerCase();
		if (normalized.includes("easy") || normalized.includes("simple")) return "Easy";
		if (normalized.includes("hard") || normalized.includes("difficult")) return "Hard";
		return "Medium";
	}
}
