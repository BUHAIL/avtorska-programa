/**
 * Environment detection utilities for CREAO platform
 * Determines whether running in preview vs production mode
 */

import { APP_CONFIG } from "@/sdk/core/global";

/**
 * Check if running inside CREAO preview environment
 * Preview mode is detected when:
 * 1. App is running in an iframe (window.parent !== window)
 * 2. AND/OR not running from a valid build URL
 *
 * In preview mode, we use simplified prompts for reliability
 */
export function isPreviewMode(): boolean {
	// Check if we're in an iframe (CREAO preview embeds the app)
	const isInIframe = window.parent !== window;

	// Check if this is not a valid production build URL
	const isNotProductionBuild = !APP_CONFIG.isValidBuildUrl;

	// Preview mode if: in iframe OR not a valid build URL
	// This ensures preview mode is active during development/testing
	return isInIframe || isNotProductionBuild;
}

/**
 * Check if running in production mode
 * Production mode is when running from a valid build URL
 */
export function isProductionMode(): boolean {
	return APP_CONFIG.isValidBuildUrl && window.parent === window;
}

/**
 * Get current environment name for logging
 */
export function getEnvironmentName(): "preview" | "production" {
	return isPreviewMode() ? "preview" : "production";
}
