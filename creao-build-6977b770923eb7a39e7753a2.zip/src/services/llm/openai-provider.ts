/**
 * OpenAI LLM Provider
 * Implements the abstract LLM provider interface using OpenAI's API
 */

import type {
	LLMProvider,
	LLMMessage,
	LLMResponse,
	LLMProviderConfig,
	RecipeGenerationRequest,
} from "./types";
import type { Recipe, RecipeCategory, RecipeDifficulty } from "@/types/recipe";

export class OpenAIProvider implements LLMProvider {
	private config: LLMProviderConfig;
	private baseURL = "https://api.openai.com/v1";

	constructor(config: LLMProviderConfig) {
		this.config = config;
	}

	async generateCompletion(messages: LLMMessage[]): Promise<LLMResponse> {
		const response = await fetch(`${this.baseURL}/chat/completions`, {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				Authorization: `Bearer ${this.config.apiKey}`,
			},
			body: JSON.stringify({
				model: this.config.model,
				messages: messages,
				temperature: this.config.temperature ?? 0.7,
				max_tokens: this.config.maxTokens ?? 2000,
			}),
		});

		if (!response.ok) {
			const error = await response.json().catch(() => ({ error: { message: "Unknown error" } }));
			throw new Error(
				`OpenAI API error: ${error.error?.message || response.statusText}`,
			);
		}

		const data = await response.json();
		const choice = data.choices?.[0];

		return {
			content: choice?.message?.content || "",
			finishReason: choice?.finish_reason,
			usage: {
				promptTokens: data.usage?.prompt_tokens || 0,
				completionTokens: data.usage?.completion_tokens || 0,
				totalTokens: data.usage?.total_tokens || 0,
			},
		};
	}

	async generateRecipes(request: RecipeGenerationRequest): Promise<Recipe[]> {
		const { ingredients, preferences, language = "en" } = request;

		// Language names for LLM instruction
		const languageNames: Record<string, string> = {
			en: "English",
			ru: "Russian",
			es: "Spanish",
		};
		const targetLanguage = languageNames[language] || "English";

		// Build the user prompt
		let userPrompt = `I have these ingredients: ${ingredients}\n\n`;

		if (preferences?.dietaryPreferences?.length) {
			userPrompt += `Dietary restrictions: ${preferences.dietaryPreferences.join(", ")}\n`;
		}

		if (preferences?.dislikedIngredients?.length) {
			userPrompt += `Ingredients to avoid: ${preferences.dislikedIngredients.join(", ")}\n`;
		}

		if (preferences?.healthGoals?.length) {
			userPrompt += `Health goals: ${preferences.healthGoals.join(", ")}\n`;
		}

		if (preferences?.preferredCuisines?.length) {
			userPrompt += `Preferred cuisines: ${preferences.preferredCuisines.join(", ")}\n`;
		}

		userPrompt += `\nIMPORTANT: Generate ALL recipe content (titles, descriptions, ingredients, instructions) in ${targetLanguage}. The entire response must be in ${targetLanguage}.

Please create 3 recipe variations: one fast (under 30 min), one medium (30-60 min), and one that takes more time but is more elaborate. For each recipe, provide the response in the following JSON format:

{
  "recipes": [
    {
      "title": "Recipe Name in ${targetLanguage}",
      "description": "A brief, enticing description in ${targetLanguage}",
      "ingredients": ["ingredient 1 with amount in ${targetLanguage}", "ingredient 2 with amount in ${targetLanguage}"],
      "instructions": ["step 1 in ${targetLanguage}", "step 2 in ${targetLanguage}"],
      "category": "Fast" | "Medium" | "Regular",
      "cookingTime": number (in minutes),
      "difficulty": "Easy" | "Medium" | "Hard"
    }
  ]
}

Make the recipes practical, delicious, and use the ingredients I provided as the main components. Be friendly and encouraging in your descriptions! Remember: ALL text content must be in ${targetLanguage}.`;

		const messages: LLMMessage[] = [
			{
				role: "system",
				content:
					this.config.systemPrompt ||
					`You are a friendly AI chef assistant. You help home cooks create delicious recipes from ingredients they have on hand. Your recipes are practical, easy to follow, and use a warm, encouraging tone. Always provide clear measurements and step-by-step instructions.`,
			},
			{
				role: "user",
				content: userPrompt,
			},
		];

		const response = await this.generateCompletion(messages);

		// Parse the JSON response
		try {
			const content = response.content.trim();
			// Extract JSON from markdown code blocks if present
			const jsonMatch = content.match(/```(?:json)?\s*(\{[\s\S]*\})\s*```/) || [
				null,
				content,
			];
			const jsonStr = jsonMatch[1] || content;

			const parsed = JSON.parse(jsonStr);
			const recipesData = parsed.recipes || [];

			// Transform to our Recipe type with generated IDs and timestamps
			return recipesData.map((r: any) => ({
				id: crypto.randomUUID(),
				title: r.title,
				description: r.description,
				ingredients: r.ingredients,
				instructions: r.instructions,
				category: r.category as RecipeCategory,
				cookingTime: r.cookingTime,
				difficulty: r.difficulty as RecipeDifficulty,
				generatedAt: new Date().toISOString(),
			}));
		} catch (error) {
			console.error("Failed to parse recipe JSON:", error);
			throw new Error(
				"Failed to parse recipes from AI response. Please try again.",
			);
		}
	}
}
