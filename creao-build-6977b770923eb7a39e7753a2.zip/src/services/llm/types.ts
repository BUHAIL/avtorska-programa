/**
 * Abstract LLM provider types
 * Allows swapping between OpenAI, Anthropic, Gemini, etc.
 */

import type { Recipe, UserPreferences } from "@/types/recipe";

export interface LLMMessage {
	role: "system" | "user" | "assistant";
	content: string;
}

export interface LLMResponse {
	content: string;
	finishReason?: string;
	usage?: {
		promptTokens: number;
		completionTokens: number;
		totalTokens: number;
	};
}

export interface LLMProviderConfig {
	apiKey: string;
	model: string;
	temperature?: number;
	maxTokens?: number;
	systemPrompt?: string;
}

export interface RecipeGenerationRequest {
	ingredients: string;
	preferences?: UserPreferences;
	language?: string;
}

/**
 * Abstract interface that all LLM providers must implement
 */
export interface LLMProvider {
	/**
	 * Generate chat completion
	 */
	generateCompletion(messages: LLMMessage[]): Promise<LLMResponse>;

	/**
	 * Generate recipes based on ingredients and preferences
	 */
	generateRecipes(request: RecipeGenerationRequest): Promise<Recipe[]>;
}
