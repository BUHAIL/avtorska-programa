import { Card, CardContent } from "@/components/ui/card";
import { Crown } from "lucide-react";
import { cn } from "@/lib/utils";
import { useTranslations } from "@/i18n";

interface AdBannerProps {
	className?: string;
}

/**
 * Static ad banner for free users
 * In production, integrate with ad network SDK
 */
export function AdBanner({ className }: AdBannerProps) {
	const t = useTranslations();

	return (
		<Card className={cn("border-dashed border-gray-300 dark:border-gray-700 bg-gray-50/50 dark:bg-gray-800/30 animate-fade-in", className)}>
			<CardContent className="pt-4 pb-4">
				<div className="text-center">
					<p className="text-xs text-gray-400 dark:text-gray-500 mb-3 font-medium uppercase tracking-wide">
						{t.ads.sponsored}
					</p>
					<div className="bg-gradient-to-br from-gray-100 to-gray-50 dark:from-gray-800 dark:to-gray-900 rounded-lg p-6 border border-gray-200 dark:border-gray-700">
						<p className="text-sm text-gray-500 dark:text-gray-400 mb-3">
							{t.ads.adSpace}
						</p>
						<div className="flex items-center justify-center gap-2 text-xs text-gray-400 dark:text-gray-500">
							<Crown className="h-3 w-3" />
							<span>{t.ads.adFreeWithPremium}</span>
						</div>
					</div>
				</div>
			</CardContent>
		</Card>
	);
}
