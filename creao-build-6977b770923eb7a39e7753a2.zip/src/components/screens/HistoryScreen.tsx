import { useNavigate } from "@tanstack/react-router";
import { ArrowLeft, Clock, ChefHat, Crown, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useRecipeHistory } from "@/hooks/use-recipe-history";
import { useSubscription } from "@/hooks/use-subscription";
import { useTranslations } from "@/i18n";
import { recipeStore } from "@/lib/recipe-store";
import type { Recipe } from "@/types/recipe";

export function HistoryScreen() {
	const navigate = useNavigate();
	const { recipes, isLoading } = useRecipeHistory();
	const { subscription } = useSubscription();
	const t = useTranslations();

	const getCategoryLabel = (category: Recipe["category"]) => {
		switch (category) {
			case "Fast":
				return t.categories.fast;
			case "Medium":
				return t.categories.medium;
			case "Regular":
				return t.categories.regular;
		}
	};

	const getCategoryColor = (category: Recipe["category"]) => {
		switch (category) {
			case "Fast":
				return "bg-green-500";
			case "Medium":
				return "bg-yellow-500";
			case "Regular":
				return "bg-orange-500";
		}
	};

	const formatDate = (timestamp: string) => {
		// Handle both ISO string and Unix timestamp formats
		const date = new Date(isNaN(Number(timestamp)) ? timestamp : Number(timestamp) * 1000);
		return date.toLocaleDateString(undefined, {
			month: "short",
			day: "numeric",
			year: "numeric",
		});
	};

	const handleRecipeClick = (recipe: Recipe) => {
		// Store the recipe so it can be viewed
		recipeStore.setRecipes([recipe]);
		navigate({
			to: "/recipes/$recipeId",
			params: { recipeId: recipe.id },
		});
	};

	// Show upgrade prompt for non-premium users
	if (!subscription.isPremium) {
		return (
			<div className="min-h-screen bg-gradient-to-br from-orange-50 via-amber-50/30 to-white dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 p-4">
				<div className="max-w-2xl mx-auto py-6 md:py-8">
					<Button
						variant="ghost"
						onClick={() => navigate({ to: "/" })}
						className="mb-6 hover-lift"
					>
						<ArrowLeft className="h-4 w-4 mr-2" />
						{t.nav.backToHome}
					</Button>

					<Card className="text-center py-12 animate-fade-in">
						<CardContent className="space-y-6">
							<div className="text-6xl mb-4">🔒</div>
							<div>
								<h2 className="text-2xl font-bold text-gray-800 dark:text-gray-200 mb-2">
									{t.history.proOnly.title}
								</h2>
								<p className="text-gray-600 dark:text-gray-400 max-w-md mx-auto">
									{t.history.proOnly.description}
								</p>
							</div>
							<Button
								onClick={() => navigate({ to: "/premium" })}
								className="gap-2 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600"
							>
								<Crown className="h-4 w-4" />
								{t.premium.upgradeButton}
							</Button>
						</CardContent>
					</Card>
				</div>
			</div>
		);
	}

	return (
		<div className="min-h-screen bg-gradient-to-br from-orange-50 via-amber-50/30 to-white dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 p-4">
			<div className="max-w-4xl mx-auto py-6 md:py-8">
				<Button
					variant="ghost"
					onClick={() => navigate({ to: "/" })}
					className="mb-6 hover-lift"
				>
					<ArrowLeft className="h-4 w-4 mr-2" />
					{t.nav.backToHome}
				</Button>

				<div className="mb-8 animate-fade-in">
					<div className="flex items-center gap-3 mb-3">
						<div className="text-3xl">📚</div>
						<h1 className="text-2xl md:text-3xl font-bold bg-gradient-to-r from-orange-600 to-amber-600 bg-clip-text text-transparent">
							{t.history.title}
						</h1>
					</div>
					<p className="text-base md:text-lg text-gray-600 dark:text-gray-300 ml-12">
						{t.history.subtitle}
					</p>
				</div>

				{isLoading ? (
					<div className="text-center py-12 animate-fade-in">
						<div className="text-6xl mb-4 animate-bounce-subtle">👨‍🍳</div>
						<p className="text-gray-600 dark:text-gray-400">Loading...</p>
					</div>
				) : recipes.length === 0 ? (
					<Card className="text-center py-12 animate-fade-in">
						<CardContent className="space-y-4">
							<div className="text-6xl mb-4">📭</div>
							<div>
								<h2 className="text-xl font-bold text-gray-800 dark:text-gray-200 mb-2">
									{t.history.empty.title}
								</h2>
								<p className="text-gray-600 dark:text-gray-400">
									{t.history.empty.description}
								</p>
							</div>
							<Button
								onClick={() => navigate({ to: "/" })}
								className="gap-2 bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600"
							>
								<Sparkles className="h-4 w-4" />
								{t.home.generateButton}
							</Button>
						</CardContent>
					</Card>
				) : (
					<div className="space-y-4">
						{recipes.map((recipe, index) => (
							<Card
								key={recipe.id}
								className={`cursor-pointer hover-lift transition-smooth border-2 hover:border-orange-300 dark:hover:border-orange-700 animate-slide-up`}
								style={{ animationDelay: `${index * 100}ms` }}
								onClick={() => handleRecipeClick(recipe)}
							>
								<CardHeader className="pb-2">
									<div className="flex justify-between items-start">
										<div className="flex-1">
											<CardTitle className="text-lg">{recipe.title}</CardTitle>
											<CardDescription className="mt-1 line-clamp-2">
												{recipe.description}
											</CardDescription>
										</div>
									</div>
									<div className="flex gap-2 mt-3 flex-wrap">
										<Badge className={getCategoryColor(recipe.category)}>
											{getCategoryLabel(recipe.category)}
										</Badge>
										<Badge variant="outline" className="gap-1">
											<Clock className="h-3 w-3" />
											{t.results.minutes.replace("{count}", String(recipe.cookingTime))}
										</Badge>
										<Badge variant="outline" className="gap-1">
											<ChefHat className="h-3 w-3" />
											{t.results.ingredients.replace("{count}", String(recipe.ingredients.length))}
										</Badge>
									</div>
								</CardHeader>
								<CardContent className="pt-2">
									<p className="text-xs text-gray-500 dark:text-gray-400">
										{t.history.generatedOn.replace("{date}", formatDate(recipe.generatedAt))}
									</p>
								</CardContent>
							</Card>
						))}
					</div>
				)}
			</div>
		</div>
	);
}
