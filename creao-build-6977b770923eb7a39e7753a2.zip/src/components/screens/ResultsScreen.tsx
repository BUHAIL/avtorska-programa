import { useEffect, useState, useCallback } from "react";
import { useNavigate, useSearch } from "@tanstack/react-router";
import { Clock, ChefHat, ArrowLeft, RefreshCw, Search, Lightbulb } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Skeleton } from "@/components/ui/skeleton";
import { generateRecipes } from "@/services/recipe-service";
import { useUserPreferences } from "@/hooks/use-user-preferences";
import { useRecipeHistory } from "@/hooks/use-recipe-history";
import { useSubscription } from "@/hooks/use-subscription";
import { useOnboarding } from "@/hooks/use-onboarding";
import { AdBanner } from "@/components/AdBanner";
import { recipeStore } from "@/lib/recipe-store";
import { useLanguage, useTranslations } from "@/i18n";
import type { Recipe } from "@/types/recipe";

export function ResultsScreen() {
	const navigate = useNavigate();
	const searchParams = useSearch({ from: "/results" }) as any;
	const [recipes, setRecipes] = useState<Recipe[]>([]);
	const [isLoading, setIsLoading] = useState(true);
	const [error, setError] = useState<string | null>(null);
	const [loadingTipIndex, setLoadingTipIndex] = useState(0);

	const { preferences } = useUserPreferences();
	const { saveRecipes } = useRecipeHistory();
	const { subscription } = useSubscription();
	const { isFirstRecipe, markFirstRecipe, visitCount } = useOnboarding();
	const { language } = useLanguage();
	const t = useTranslations();
	const [showCelebration, setShowCelebration] = useState(false);

	// Rotate loading tips
	useEffect(() => {
		if (!isLoading) return;
		const interval = setInterval(() => {
			setLoadingTipIndex((prev) => (prev + 1) % t.results.loading.tips.length);
		}, 2500);
		return () => clearInterval(interval);
	}, [isLoading, t.results.loading.tips.length]);

	const loadRecipes = useCallback(async () => {
		if (!searchParams?.ingredients) {
			navigate({ to: "/" });
			return;
		}

		try {
			setIsLoading(true);
			setError(null);
			setLoadingTipIndex(0);
			const generated = await generateRecipes(
				searchParams.ingredients,
				preferences,
				language,
			);
			setRecipes(generated);
			// Only save to history for premium users
			if (subscription.isPremium) {
				saveRecipes(generated);
			}
			recipeStore.setRecipes(generated);

			// Show celebration for first-time recipe generation
			if (isFirstRecipe && generated.length > 0) {
				setShowCelebration(true);
				markFirstRecipe();
				// Auto-dismiss after 5 seconds
				setTimeout(() => setShowCelebration(false), 5000);
			}
		} catch (err) {
			setError(
				err instanceof Error ? err.message : t.errors.generationFailed,
			);
		} finally {
			setIsLoading(false);
		}
	}, [searchParams?.ingredients, preferences, language, saveRecipes, navigate, t.errors.generationFailed, subscription.isPremium]);

	useEffect(() => {
		loadRecipes();
	}, [loadRecipes]);

	const getCategoryColor = (category: Recipe["category"]) => {
		switch (category) {
			case "Fast":
				return "bg-green-500";
			case "Medium":
				return "bg-yellow-500";
			case "Regular":
				return "bg-orange-500";
		}
	};

	const getCategoryLabel = (category: Recipe["category"]) => {
		switch (category) {
			case "Fast":
				return t.categories.fast;
			case "Medium":
				return t.categories.medium;
			case "Regular":
				return t.categories.regular;
		}
	};

	const getDifficultyColor = (difficulty: Recipe["difficulty"]) => {
		switch (difficulty) {
			case "Easy":
				return "bg-blue-500";
			case "Medium":
				return "bg-purple-500";
			case "Hard":
				return "bg-red-500";
		}
	};

	const getDifficultyLabel = (difficulty: Recipe["difficulty"]) => {
		switch (difficulty) {
			case "Easy":
				return t.difficulty.easy;
			case "Medium":
				return t.difficulty.medium;
			case "Hard":
				return t.difficulty.hard;
		}
	};

	return (
		<div className="min-h-screen bg-gradient-to-br from-orange-50 via-amber-50/30 to-white dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 p-4">
			<div className="max-w-4xl mx-auto py-6 md:py-8">
				<Button
					variant="ghost"
					onClick={() => navigate({ to: "/" })}
					className="mb-6 hover-lift"
				>
					<ArrowLeft className="h-4 w-4 mr-2" />
					{t.nav.backToHome}
				</Button>

				{/* First Success Celebration */}
				{showCelebration && (
					<div className="mb-6 bg-gradient-to-r from-green-100 to-emerald-100 dark:from-green-900/30 dark:to-emerald-900/30 rounded-xl p-4 border border-green-200 dark:border-green-800 animate-slide-up">
						<div className="flex items-center gap-3">
							<span className="text-3xl">🎉</span>
							<div>
								<p className="font-semibold text-green-900 dark:text-green-100">
									{t.onboarding.firstSuccess.title}
								</p>
								<p className="text-sm text-green-800 dark:text-green-200">
									{t.onboarding.firstSuccess.subtitle}
								</p>
							</div>
						</div>
					</div>
				)}

				{!isLoading && recipes.length > 0 && (
					<div className="mb-8 animate-fade-in">
						<div className="flex items-center gap-3 mb-3">
							<div className="text-3xl">✨</div>
							<h1 className="text-2xl md:text-3xl font-bold bg-gradient-to-r from-orange-600 to-amber-600 bg-clip-text text-transparent">
								{t.results.title}
							</h1>
						</div>
						<p className="text-base md:text-lg text-gray-600 dark:text-gray-300 ml-12">
							{t.results.subtitle
								.replace("{count}", String(recipes.length))
								.replace("{recipes}", recipes.length === 1 ? "recipe" : "recipes")}
						</p>
					</div>
				)}

				{error && (
					<div className="mb-6 animate-fade-in">
						<Alert variant="destructive" className="mb-4">
							<AlertDescription>{error}</AlertDescription>
						</Alert>
						<div className="flex gap-3 justify-center">
							<Button
								variant="outline"
								onClick={() => loadRecipes()}
								className="gap-2 hover-lift"
							>
								<RefreshCw className="h-4 w-4" />
								{t.results.tryAgain}
							</Button>
							<Button
								variant="default"
								onClick={() => navigate({ to: "/" })}
								className="gap-2 bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600"
							>
								<Search className="h-4 w-4" />
								{t.results.newSearch}
							</Button>
						</div>
					</div>
				)}

				{isLoading ? (
					<div className="space-y-6">
						<div className="text-center py-12 animate-fade-in">
							<div className="text-6xl mb-4 animate-bounce-subtle">👨‍🍳</div>
							<h2 className="text-2xl font-bold text-gray-800 dark:text-gray-200 mb-2">
								{t.results.loading.title}
							</h2>
							<p className="text-gray-600 dark:text-gray-400 mb-4">
								{t.results.loading.description}
							</p>
							<p className="text-sm text-orange-600 dark:text-orange-400 font-medium transition-opacity duration-300">
								{t.results.loading.tips[loadingTipIndex]}
							</p>
						</div>
						{[1, 2, 3].map((i) => (
							<Card key={i} className="overflow-hidden animate-fade-in delay-${i}00">
								<CardHeader>
									<Skeleton className="h-6 w-3/4 loading-shimmer" />
									<Skeleton className="h-4 w-full mt-2 loading-shimmer" />
								</CardHeader>
								<CardContent>
									<Skeleton className="h-20 w-full loading-shimmer" />
								</CardContent>
							</Card>
						))}
					</div>
				) : (
					<div className="space-y-6">
						{recipes.map((recipe, index) => (
							<Card
								key={recipe.id}
								className={`cursor-pointer hover-lift transition-smooth border-2 hover:border-orange-300 dark:hover:border-orange-700 animate-slide-up delay-${index}00`}
								onClick={() =>
									navigate({
										to: "/recipes/$recipeId",
										params: { recipeId: recipe.id },
									})
								}
							>
								<CardHeader>
									<div className="flex justify-between items-start">
										<div className="flex-1">
											<CardTitle>{recipe.title}</CardTitle>
											<CardDescription className="mt-2">
												{recipe.description}
											</CardDescription>
										</div>
									</div>
									<div className="flex gap-2 mt-4 flex-wrap">
										<Badge className={getCategoryColor(recipe.category)}>
											{getCategoryLabel(recipe.category)}
										</Badge>
										<Badge
											variant="outline"
											className={getDifficultyColor(recipe.difficulty)}
										>
											{getDifficultyLabel(recipe.difficulty)}
										</Badge>
										<Badge variant="outline" className="gap-1">
											<Clock className="h-3 w-3" />
											{t.results.minutes.replace("{count}", String(recipe.cookingTime))}
										</Badge>
										<Badge variant="outline" className="gap-1">
											<ChefHat className="h-3 w-3" />
											{t.results.ingredients.replace("{count}", String(recipe.ingredients.length))}
										</Badge>
									</div>
								</CardHeader>
								<CardContent>
									<div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
										<ChefHat className="h-4 w-4 text-orange-500" />
										<span>{t.results.tapToView}</span>
									</div>
								</CardContent>
							</Card>
						))}
					</div>
				)}

				{/* Return Usage Tips - shown occasionally */}
				{!isLoading && recipes.length > 0 && visitCount > 0 && visitCount <= 3 && (
					<div className="mt-6 bg-gray-50 dark:bg-gray-800/50 rounded-lg p-4 border border-gray-200 dark:border-gray-700 animate-fade-in">
						<div className="flex items-start gap-3">
							<Lightbulb className="h-5 w-5 text-amber-500 mt-0.5 shrink-0" />
							<p className="text-sm text-gray-600 dark:text-gray-400">
								{visitCount === 1
									? t.onboarding.returnTips.preferences
									: t.onboarding.returnTips.voice}
							</p>
						</div>
					</div>
				)}

				{!subscription.isPremium && !isLoading && (
					<AdBanner className="mt-6" />
				)}
			</div>
		</div>
	);
}
