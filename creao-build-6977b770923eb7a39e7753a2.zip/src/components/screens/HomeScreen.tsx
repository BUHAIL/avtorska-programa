import { useState, useEffect } from "react";
import { useNavigate } from "@tanstack/react-router";
import { Mic, Sparkles, Settings, Crown, X, Clock, History } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useVoiceInput } from "@/hooks/use-voice-input";
import { useSubscription } from "@/hooks/use-subscription";
import { useOnboarding } from "@/hooks/use-onboarding";
import { useRequestLimits } from "@/hooks/use-request-limits";
import { validateIngredients } from "@/services/recipe-service";
import { AdBanner } from "@/components/AdBanner";
import { useTranslations } from "@/i18n";

export function HomeScreen() {
	const navigate = useNavigate();
	const [ingredients, setIngredients] = useState("");
	const [error, setError] = useState<string | null>(null);
	const [showWelcome, setShowWelcome] = useState(false);
	const { isListening, isSupported, startListening, error: voiceError } = useVoiceInput();
	const { subscription } = useSubscription();
	const { isFirstVisit, markVisited, isLoaded } = useOnboarding();
	const t = useTranslations();
	const {
		remainingRequests,
		isLimitExhausted,
		useRequest,
		getTimeUntilReset,
		isUnlimited,
		dailyLimit,
	} = useRequestLimits(subscription.isPremium);

	// Show welcome hint for first-time users
	useEffect(() => {
		if (isLoaded && isFirstVisit) {
			setShowWelcome(true);
			markVisited();
		}
	}, [isLoaded, isFirstVisit, markVisited]);

	const handleVoiceInput = () => {
		startListening((text) => {
			setIngredients((prev) => (prev ? `${prev}, ${text}` : text));
		});
	};

	const handleGenerate = () => {
		// Check request limits for free users
		if (isLimitExhausted) {
			setError(t.limits.exhausted.description);
			return;
		}

		const validation = validateIngredients(ingredients);
		if (!validation.valid) {
			setError(validation.error || t.errors.invalidIngredients);
			return;
		}

		// Use a request (decrement counter for free users)
		const allowed = useRequest();
		if (!allowed) {
			setError(t.limits.exhausted.description);
			return;
		}

		setError(null);
		navigate({
			to: "/results",
			search: { ingredients },
		});
	};

	return (
		<div className="min-h-screen bg-gradient-to-br from-orange-50 via-amber-50/30 to-white dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 p-4">
			<div className="max-w-2xl mx-auto py-6 md:py-12">
				{/* Header */}
				<div className="flex justify-between items-start mb-8 md:mb-12 animate-fade-in">
					<div className="flex-1">
						<div className="flex items-center gap-3 mb-2">
							<div className="text-4xl">👨‍🍳</div>
							<h1 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-orange-600 to-amber-600 bg-clip-text text-transparent">
								{t.app.name}
							</h1>
						</div>
						<p className="text-base md:text-lg text-gray-600 dark:text-gray-300 font-medium">
							{t.app.tagline}
						</p>
						<p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
							{t.app.trustBadge}
						</p>
					</div>
					<div className="flex gap-2 items-center">
						{subscription.isPremium && (
							<Button
								variant="ghost"
								size="icon"
								onClick={() => navigate({ to: "/history" })}
								className="hover-lift"
								aria-label={t.nav.history}
							>
								<History className="h-5 w-5" />
							</Button>
						)}
						<Button
							variant="ghost"
							size="icon"
							onClick={() => navigate({ to: "/preferences" })}
							className="hover-lift"
							aria-label={t.nav.settings}
						>
							<Settings className="h-5 w-5" />
						</Button>
						{!subscription.isPremium && (
							<Button
								variant="default"
								size="sm"
								onClick={() => navigate({ to: "/premium" })}
								className="gap-2 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 hover-lift active-press"
							>
								<Crown className="h-4 w-4" />
								<span className="hidden sm:inline">{t.nav.premium}</span>
							</Button>
						)}
					</div>
				</div>

				{/* Welcome Banner for First-time Users */}
				{showWelcome && (
					<div className="mb-6 bg-gradient-to-r from-orange-100 to-amber-100 dark:from-orange-900/30 dark:to-amber-900/30 rounded-xl p-4 border border-orange-200 dark:border-orange-800 animate-slide-up relative">
						<button
							onClick={() => setShowWelcome(false)}
							className="absolute top-2 right-2 p-1 rounded-full hover:bg-orange-200 dark:hover:bg-orange-800/50 transition-colors"
							aria-label={t.onboarding.welcome.dismiss}
						>
							<X className="h-4 w-4 text-orange-600 dark:text-orange-400" />
						</button>
						<div className="flex items-start gap-3 pr-6">
							<span className="text-2xl">👋</span>
							<div>
								<p className="font-semibold text-orange-900 dark:text-orange-100 mb-1">
									{t.onboarding.welcome.title}
								</p>
								<p className="text-sm text-orange-800 dark:text-orange-200">
									{t.onboarding.welcome.description}
								</p>
								<p className="text-xs text-orange-700 dark:text-orange-300 mt-2">
									{t.onboarding.hints.voice}
								</p>
							</div>
						</div>
					</div>
				)}

				{/* Limit Exhausted Warning */}
				{isLimitExhausted && (
					<div className="mb-6 bg-gradient-to-r from-red-100 to-orange-100 dark:from-red-900/30 dark:to-orange-900/30 rounded-xl p-4 border border-red-200 dark:border-red-800 animate-slide-up">
						<div className="flex items-start gap-3">
							<Clock className="h-5 w-5 text-red-600 dark:text-red-400 mt-0.5 shrink-0" />
							<div className="flex-1">
								<p className="font-semibold text-red-900 dark:text-red-100 mb-1">
									{t.limits.exhausted.title}
								</p>
								<p className="text-sm text-red-800 dark:text-red-200">
									{t.limits.exhausted.resetIn.replace("{time}", getTimeUntilReset())}
								</p>
								<Button
									variant="link"
									className="p-0 h-auto text-sm text-amber-600 dark:text-amber-400 font-medium mt-2"
									onClick={() => navigate({ to: "/premium" })}
								>
									<Crown className="h-4 w-4 mr-1" />
									{t.limits.upgradePrompt}
								</Button>
							</div>
						</div>
					</div>
				)}

				{/* Remaining Requests Counter for Free Users */}
				{!isUnlimited && !isLimitExhausted && remainingRequests > 0 && (
					<div className="mb-4 flex justify-center animate-fade-in">
						<div className="inline-flex items-center gap-2 px-3 py-1.5 bg-amber-100 dark:bg-amber-900/30 rounded-full border border-amber-200 dark:border-amber-800">
							<Clock className="h-4 w-4 text-amber-600 dark:text-amber-400" />
							<span className="text-sm font-medium text-amber-800 dark:text-amber-200">
								{t.limits.remaining.replace("{count}", String(remainingRequests))}
							</span>
						</div>
					</div>
				)}

				{/* Main Input Card */}
				<Card className="border-2 shadow-xl hover:shadow-2xl transition-shadow duration-300 animate-slide-up">
					<CardHeader className="text-center pb-4">
						<CardTitle className="text-2xl md:text-3xl">{t.home.title}</CardTitle>
						<CardDescription className="text-base mt-2">
							{t.home.subtitle}
						</CardDescription>
					</CardHeader>
					<CardContent className="space-y-6">
						<div className="relative">
							<Textarea
								placeholder={t.home.inputPlaceholder}
								value={ingredients}
								onChange={(e) => setIngredients(e.target.value)}
								className="min-h-36 text-base resize-none focus:ring-2 focus:ring-orange-400 transition-all pr-14"
								aria-label={t.home.inputPlaceholder}
							/>
							{isSupported && (
								<Button
									variant={isListening ? "default" : "outline"}
									size="icon"
									className={`absolute bottom-3 right-3 hover-lift active-press ${
										isListening ? "bg-red-500 hover:bg-red-600 animate-pulse-slow" : ""
									}`}
									onClick={handleVoiceInput}
									disabled={isListening}
									aria-label={isListening ? t.home.voiceInputListening : t.home.voiceInputStart}
								>
									<Mic className="h-5 w-5" />
								</Button>
							)}
							<p className="text-xs text-gray-500 dark:text-gray-400 mt-2">
								{t.home.inputHelper}
							</p>
						</div>

						{!ingredients.trim() && !error && !voiceError && (
							<div className="bg-amber-50 dark:bg-amber-900/20 rounded-lg p-4 border border-amber-200 dark:border-amber-800">
								<p className="text-sm text-amber-800 dark:text-amber-200 font-medium mb-2">
									💡 {t.home.inspirationHint}
								</p>
								<div className="flex flex-wrap gap-2">
									{[
										{ key: "chickenRice", text: t.home.examples.chickenRice },
										{ key: "pastaTomatoes", text: t.home.examples.pastaTomatoes },
										{ key: "eggsCheese", text: t.home.examples.eggsCheese },
									].map(({ key, text }) => (
										<button
											key={key}
											onClick={() => setIngredients(text.toLowerCase())}
											className="text-sm px-4 py-2 bg-white dark:bg-gray-800 rounded-full border-2 border-amber-300 dark:border-amber-700 hover:bg-amber-100 dark:hover:bg-amber-900/40 hover:border-amber-400 dark:hover:border-amber-600 transition-all hover-lift active-press font-medium"
										>
											{text}
										</button>
									))}
								</div>
								<p className="text-xs text-amber-600 dark:text-amber-400 mt-3">
									{t.onboarding.hints.examples}
								</p>
							</div>
						)}

						{(error || voiceError) && (
							<Alert variant="destructive" className="animate-fade-in">
								<AlertDescription className="text-sm">{error || voiceError}</AlertDescription>
							</Alert>
						)}

						<Button
							onClick={handleGenerate}
							className="w-full gap-3 h-14 text-lg font-semibold bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600 shadow-lg hover:shadow-xl transition-all duration-300 active-press"
							disabled={!ingredients.trim()}
							aria-label={t.home.generateButton}
						>
							<Sparkles className="h-6 w-6" />
							{t.home.generateButton}
						</Button>
					</CardContent>
				</Card>

				{/* Ad Banner for Free Users */}
				{!subscription.isPremium && <AdBanner className="mt-8" />}

				{/* Features */}
				<div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-8 mb-6">
					<Card className="hover-lift transition-smooth delay-100 animate-fade-in border-none shadow-md">
						<CardContent className="pt-6 pb-6">
							<div className="text-center">
								<div className="text-4xl mb-3">🍳</div>
								<h3 className="font-semibold text-base mb-2">{t.home.features.smartAI.title}</h3>
								<p className="text-sm text-gray-600 dark:text-gray-400 leading-relaxed">
									{t.home.features.smartAI.description}
								</p>
							</div>
						</CardContent>
					</Card>
					<Card className="hover-lift transition-smooth delay-200 animate-fade-in border-none shadow-md">
						<CardContent className="pt-6 pb-6">
							<div className="text-center">
								<div className="text-4xl mb-3">⚡</div>
								<h3 className="font-semibold text-base mb-2">{t.home.features.variations.title}</h3>
								<p className="text-sm text-gray-600 dark:text-gray-400 leading-relaxed">
									{t.home.features.variations.description}
								</p>
							</div>
						</CardContent>
					</Card>
					<Card className="hover-lift transition-smooth delay-300 animate-fade-in border-none shadow-md">
						<CardContent className="pt-6 pb-6">
							<div className="text-center">
								<div className="text-4xl mb-3">🎯</div>
								<h3 className="font-semibold text-base mb-2">{t.home.features.yourTaste.title}</h3>
								<p className="text-sm text-gray-600 dark:text-gray-400 leading-relaxed">
									{t.home.features.yourTaste.description}
								</p>
							</div>
						</CardContent>
					</Card>
				</div>
			</div>
		</div>
	);
}
