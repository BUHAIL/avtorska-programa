import { useNavigate, useParams } from "@tanstack/react-router";
import { ArrowLeft, Clock, ChefHat } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { recipeStore } from "@/lib/recipe-store";
import { useTranslations } from "@/i18n";

export function RecipeDetailScreen() {
	const navigate = useNavigate();
	const params = useParams({ from: "/recipes/$recipeId" });
	const recipe = recipeStore.getRecipe(params.recipeId);
	const t = useTranslations();

	if (!recipe) {
		return (
			<div className="min-h-screen bg-gradient-to-b from-orange-50 to-white dark:from-gray-900 dark:to-gray-800 p-4">
				<div className="max-w-3xl mx-auto py-8">
					<Alert variant="destructive">
						<AlertDescription>
							{t.recipe.notFound}
						</AlertDescription>
					</Alert>
					<Button onClick={() => navigate({ to: "/" })} className="mt-4">
						{t.recipe.goToHome}
					</Button>
				</div>
			</div>
		);
	}

	const getCategoryColor = (category: typeof recipe.category) => {
		switch (category) {
			case "Fast":
				return "bg-green-500";
			case "Medium":
				return "bg-yellow-500";
			case "Regular":
				return "bg-orange-500";
		}
	};

	const getCategoryLabel = (category: typeof recipe.category) => {
		switch (category) {
			case "Fast":
				return t.categories.fast;
			case "Medium":
				return t.categories.medium;
			case "Regular":
				return t.categories.regular;
		}
	};

	const getDifficultyColor = (difficulty: typeof recipe.difficulty) => {
		switch (difficulty) {
			case "Easy":
				return "bg-blue-500";
			case "Medium":
				return "bg-purple-500";
			case "Hard":
				return "bg-red-500";
		}
	};

	const getDifficultyLabel = (difficulty: typeof recipe.difficulty) => {
		switch (difficulty) {
			case "Easy":
				return t.difficulty.easy;
			case "Medium":
				return t.difficulty.medium;
			case "Hard":
				return t.difficulty.hard;
		}
	};

	return (
		<div className="min-h-screen bg-gradient-to-br from-orange-50 via-amber-50/30 to-white dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 p-4">
			<div className="max-w-3xl mx-auto py-6 md:py-8">
				<Button
					variant="ghost"
					onClick={() => navigate({ to: "/results", search: { ingredients: "" } })}
					className="mb-6 hover-lift"
				>
					<ArrowLeft className="h-4 w-4 mr-2" />
					{t.nav.backToResults}
				</Button>

				<Card className="border-2 shadow-xl animate-fade-in">
					<CardHeader className="pb-4">
						<div className="flex items-start gap-3 mb-2">
							<div className="text-3xl">🍽️</div>
							<div className="flex-1">
								<CardTitle className="text-2xl md:text-3xl leading-tight">{recipe.title}</CardTitle>
								<CardDescription className="mt-2 text-base">{recipe.description}</CardDescription>
							</div>
						</div>
						<div className="flex gap-2 mt-4 flex-wrap">
							<Badge className={getCategoryColor(recipe.category)}>
								{getCategoryLabel(recipe.category)}
							</Badge>
							<Badge variant="outline" className={getDifficultyColor(recipe.difficulty)}>
								{getDifficultyLabel(recipe.difficulty)}
							</Badge>
							<Badge variant="outline" className="gap-1">
								<Clock className="h-3 w-3" />
								{t.results.minutes.replace("{count}", String(recipe.cookingTime))}
							</Badge>
						</div>
					</CardHeader>
					<CardContent className="space-y-8">
						<div className="bg-gradient-to-br from-orange-50 to-amber-50 dark:from-orange-900/20 dark:to-amber-900/20 p-6 rounded-xl border border-orange-200 dark:border-orange-800">
							<h3 className="font-bold text-lg mb-4 flex items-center gap-2">
								<ChefHat className="h-5 w-5 text-orange-600" />
								{t.recipe.ingredients}
							</h3>
							<ul className="space-y-3">
								{recipe.ingredients.map((ingredient, index) => (
									<li key={index} className="flex items-start group">
										<span className="inline-flex items-center justify-center h-6 w-6 rounded-full bg-orange-200 dark:bg-orange-800 text-xs font-semibold text-orange-700 dark:text-orange-200 mr-3 shrink-0 mt-0.5">
											{index + 1}
										</span>
										<span className="text-gray-700 dark:text-gray-300">{ingredient}</span>
									</li>
								))}
							</ul>
						</div>

						<Separator className="my-8" />

						<div>
							<h3 className="font-bold text-xl mb-6 flex items-center gap-2">
								<span className="text-2xl">📝</span>
								{t.recipe.instructions}
							</h3>
							<ol className="space-y-5">
								{recipe.instructions.map((instruction, index) => (
									<li key={index} className="flex gap-4 group">
										<span className="inline-flex items-center justify-center h-8 w-8 rounded-full bg-gradient-to-br from-orange-500 to-amber-500 text-sm font-bold text-white shrink-0">
											{index + 1}
										</span>
										<p className="text-gray-700 dark:text-gray-300 leading-relaxed pt-1">
											{instruction}
										</p>
									</li>
								))}
							</ol>
						</div>

						<Separator className="my-8" />

						<div className="bg-gradient-to-r from-amber-50 to-orange-50 dark:from-amber-900/20 dark:to-orange-900/20 p-6 rounded-xl border-2 border-dashed border-amber-300 dark:border-amber-700">
							<div className="flex gap-3">
								<span className="text-2xl">💡</span>
								<div>
									<p className="font-semibold text-amber-900 dark:text-amber-100 mb-2">
										{t.recipe.chefTip.title}
									</p>
									<p className="text-sm text-amber-800 dark:text-amber-200 leading-relaxed">
										{t.recipe.chefTip.description}
									</p>
								</div>
							</div>
						</div>

						{/* Enjoy meal message */}
						<div className="text-center pt-4">
							<p className="text-lg font-semibold bg-gradient-to-r from-orange-600 to-amber-600 bg-clip-text text-transparent">
								{t.recipe.enjoyMeal}
							</p>
						</div>
					</CardContent>
				</Card>
			</div>
		</div>
	);
}
