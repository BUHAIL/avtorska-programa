import { useNavigate } from "@tanstack/react-router";
import { ArrowLeft, Crown, Check, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useSubscription } from "@/hooks/use-subscription";
import { useTranslations } from "@/i18n";
import { openSubscriptionManagement } from "@/lib/platform";

export function PremiumScreen() {
	const navigate = useNavigate();
	const { subscription, upgradeToPremium, isUpgrading } = useSubscription();
	const t = useTranslations();

	const features = [
		{ text: t.premium.features.adFree, highlight: true },
		{ text: t.premium.features.unlimited, highlight: true },
		{ text: t.premium.features.themes, highlight: false },
		{ text: t.premium.features.priority, highlight: false },
		{ text: t.premium.features.favorites, highlight: false },
		{ text: t.premium.features.filters, highlight: false },
	];

	return (
		<div className="min-h-screen bg-gradient-to-br from-orange-50 via-amber-50/30 to-white dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 p-4">
			<div className="max-w-2xl mx-auto py-6 md:py-8">
				<Button
					variant="ghost"
					className="mb-6 hover-lift"
					onClick={() => navigate({ to: "/" })}
				>
					<ArrowLeft className="h-4 w-4 mr-2" />
					{t.nav.backToHome}
				</Button>

				<div className="text-center mb-10 animate-fade-in">
					<div className="inline-block p-4 bg-gradient-to-br from-amber-100 to-orange-100 dark:from-amber-900/30 dark:to-orange-900/30 rounded-full mb-4">
						<Crown className="h-16 w-16 text-amber-600 dark:text-amber-400" />
					</div>
					<h1 className="text-3xl md:text-4xl font-bold mb-3 bg-gradient-to-r from-orange-600 to-amber-600 bg-clip-text text-transparent">
						{t.premium.title}
					</h1>
					<p className="text-lg text-gray-600 dark:text-gray-300">
						{t.premium.subtitle}
					</p>
				</div>

				{subscription.isPremium ? (
					<Card className="border-2 border-amber-400 dark:border-amber-600 bg-gradient-to-br from-amber-50 to-orange-50 dark:from-amber-900/20 dark:to-orange-900/20 animate-fade-in">
						<CardHeader>
							<div className="text-center">
								<div className="inline-flex items-center gap-2 bg-amber-100 dark:bg-amber-900/40 px-4 py-2 rounded-full mb-3">
									<Crown className="h-5 w-5 text-amber-600 dark:text-amber-400" />
									<span className="font-bold text-amber-900 dark:text-amber-100">{t.nav.premium}</span>
								</div>
								<CardTitle className="text-2xl mb-2">{t.premium.alreadyPremium.title}</CardTitle>
								<CardDescription className="text-base">
									{t.premium.alreadyPremium.description}
								</CardDescription>
							</div>
						</CardHeader>
						<CardContent className="pt-0">
							<div className="border-t border-amber-200 dark:border-amber-700 pt-6 mt-2">
								<Button
									variant="outline"
									onClick={() => openSubscriptionManagement()}
									className="w-full gap-2 border-amber-300 dark:border-amber-700 hover:bg-amber-100 dark:hover:bg-amber-900/40"
								>
									<ExternalLink className="h-4 w-4" />
									{t.premium.manageSubscription}
								</Button>
								<p className="text-xs text-center text-gray-500 dark:text-gray-400 mt-3">
									{t.premium.manageSubscriptionDescription}
								</p>
							</div>
						</CardContent>
					</Card>
				) : (
					<>
						<Card className="mb-6 border-2 shadow-xl animate-slide-up">
							<CardHeader className="text-center border-b pb-6">
								<div className="inline-block bg-gradient-to-r from-orange-500 to-amber-500 text-white px-3 py-1 rounded-full text-sm font-semibold mb-3">
									{t.premium.badge}
								</div>
								<CardTitle className="text-4xl font-bold mb-2">
									{t.premium.price}<span className="text-lg font-normal text-gray-600 dark:text-gray-400">{t.premium.perMonth}</span>
								</CardTitle>
								<CardDescription className="text-base">
									{t.premium.cancelAnytime}
								</CardDescription>
							</CardHeader>
							<CardContent className="pt-6 space-y-6">
								<div className="space-y-4">
									{features.map((feature) => (
										<div key={feature.text} className="flex items-center gap-3">
											<div className="bg-green-100 dark:bg-green-900/40 rounded-full p-1.5 shrink-0">
												<Check className="h-4 w-4 text-green-600 dark:text-green-400" />
											</div>
											<span className={feature.highlight ? "font-semibold" : ""}>
												{feature.text}
											</span>
										</div>
									))}
								</div>

								<Button
									onClick={() => upgradeToPremium()}
									disabled={isUpgrading}
									className="w-full gap-3 h-14 text-lg font-bold bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600 shadow-lg hover:shadow-xl transition-all active-press"
									size="lg"
								>
									<Crown className="h-6 w-6" />
									{isUpgrading ? t.premium.upgrading : t.premium.upgradeButton}
								</Button>

								<p className="text-xs text-center text-gray-500 dark:text-gray-400">
									{t.premium.demoNote}
								</p>

								<div className="flex items-center justify-center gap-2 text-sm text-green-600 dark:text-green-400 pt-2">
									<span>✓</span>
									<span>{t.premium.guarantee}</span>
								</div>
							</CardContent>
						</Card>

						<Card className="bg-gradient-to-br from-gray-50 to-white dark:from-gray-800/50 dark:to-gray-900/50 border-none shadow-md">
							<CardHeader>
								<CardTitle className="text-lg">{t.premium.whyPremium.title}</CardTitle>
							</CardHeader>
							<CardContent className="space-y-3 text-sm text-gray-600 dark:text-gray-400 leading-relaxed">
								<p>{t.premium.whyPremium.description1}</p>
								<p>{t.premium.whyPremium.description2}</p>
							</CardContent>
						</Card>
					</>
				)}
			</div>
		</div>
	);
}
