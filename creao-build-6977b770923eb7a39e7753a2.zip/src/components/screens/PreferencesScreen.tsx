import { useState, useEffect } from "react";
import { useNavigate } from "@tanstack/react-router";
import { ArrowLeft, Globe, Check, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useUserPreferences } from "@/hooks/use-user-preferences";
import { useLanguage, useTranslations, SUPPORTED_LANGUAGES, type Language } from "@/i18n";

export function PreferencesScreen() {
	const navigate = useNavigate();
	const { preferences, updatePreferences, isUpdating } = useUserPreferences();
	const { language, setLanguage } = useLanguage();
	const t = useTranslations();

	const [dietary, setDietary] = useState(preferences.dietaryPreferences.join(", "));
	const [disliked, setDisliked] = useState(preferences.dislikedIngredients.join(", "));
	const [health, setHealth] = useState(preferences.healthGoals.join(", "));
	const [cuisines, setCuisines] = useState(preferences.preferredCuisines.join(", "));
	const [showSaved, setShowSaved] = useState(false);

	// Reset saved message after animation
	useEffect(() => {
		if (showSaved) {
			const timer = setTimeout(() => setShowSaved(false), 2000);
			return () => clearTimeout(timer);
		}
	}, [showSaved]);

	const handleSave = () => {
		setShowSaved(true);
		updatePreferences({
			dietaryPreferences: dietary.split(",").map((s) => s.trim()).filter(Boolean),
			dislikedIngredients: disliked.split(",").map((s) => s.trim()).filter(Boolean),
			healthGoals: health.split(",").map((s) => s.trim()).filter(Boolean),
			preferredCuisines: cuisines.split(",").map((s) => s.trim()).filter(Boolean),
		});
	};

	const handleLanguageChange = (lang: Language) => {
		setLanguage(lang);
	};

	return (
		<div className="min-h-screen bg-gradient-to-br from-orange-50 via-amber-50/30 to-white dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 p-4">
			<div className="max-w-2xl mx-auto py-6 md:py-8">
				<Button
					variant="ghost"
					className="mb-6 hover-lift"
					onClick={() => navigate({ to: "/" })}
				>
					<ArrowLeft className="h-4 w-4 mr-2" />
					{t.nav.backToHome}
				</Button>

				<div className="mb-8 animate-fade-in">
					<div className="flex items-center gap-3 mb-2">
						<span className="text-3xl">⚙️</span>
						<h1 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-orange-600 to-amber-600 bg-clip-text text-transparent">
							{t.preferences.title}
						</h1>
					</div>
					<p className="text-base md:text-lg text-gray-600 dark:text-gray-300">
						{t.preferences.subtitle}
					</p>
				</div>

				<div className="space-y-6">
					{/* Language Selection Card */}
					<Card className="border-2 hover:shadow-lg transition-shadow animate-slide-up border-orange-200 dark:border-orange-800">
						<CardHeader>
							<CardTitle className="flex items-center gap-2 text-xl">
								<Globe className="h-6 w-6 text-orange-600" />
								{t.preferences.language.title}
							</CardTitle>
							<CardDescription className="text-base">
								{t.preferences.language.description}
							</CardDescription>
						</CardHeader>
						<CardContent>
							<div className="flex gap-3 flex-wrap">
								{SUPPORTED_LANGUAGES.map((lang) => (
									<button
										key={lang.code}
										onClick={() => handleLanguageChange(lang.code)}
										className={`flex items-center gap-2 px-4 py-3 rounded-lg border-2 transition-all ${
											language === lang.code
												? "border-orange-500 bg-orange-50 dark:bg-orange-900/30"
												: "border-gray-200 dark:border-gray-700 hover:border-orange-300 dark:hover:border-orange-700"
										}`}
									>
										<span className="text-2xl">{lang.flag}</span>
										<div className="text-left">
											<div className="font-semibold text-sm">{lang.nativeName}</div>
											<div className="text-xs text-gray-500 dark:text-gray-400">{lang.name}</div>
										</div>
										{language === lang.code && (
											<Check className="h-5 w-5 text-orange-600 ml-2" />
										)}
									</button>
								))}
							</div>
						</CardContent>
					</Card>

					<Card className="border-2 hover:shadow-lg transition-shadow animate-slide-up delay-100">
						<CardHeader>
							<CardTitle className="flex items-center gap-2 text-xl">
								<span className="text-2xl">🥗</span>
								{t.preferences.dietary.title}
							</CardTitle>
							<CardDescription className="text-base">
								{t.preferences.dietary.description}
							</CardDescription>
						</CardHeader>
						<CardContent className="space-y-4">
							<Input
								placeholder={t.preferences.dietary.placeholder}
								value={dietary}
								onChange={(e) => setDietary(e.target.value)}
								className="text-base"
							/>
							<div className="flex gap-2 flex-wrap">
								{t.preferences.dietary.tags.map((tag) => (
									<Badge
										key={tag}
										variant="outline"
										className="cursor-pointer hover:bg-orange-100 dark:hover:bg-orange-900/40 transition-colors px-3 py-1.5 text-sm"
										onClick={() => setDietary((prev) => prev ? `${prev}, ${tag}` : tag)}
									>
										+ {tag}
									</Badge>
								))}
							</div>
						</CardContent>
					</Card>

					<Card className="border-2 hover:shadow-lg transition-shadow animate-slide-up delay-200">
						<CardHeader>
							<CardTitle className="flex items-center gap-2 text-xl">
								<span className="text-2xl">🚫</span>
								{t.preferences.disliked.title}
							</CardTitle>
							<CardDescription className="text-base">
								{t.preferences.disliked.description}
							</CardDescription>
						</CardHeader>
						<CardContent>
							<Input
								placeholder={t.preferences.disliked.placeholder}
								value={disliked}
								onChange={(e) => setDisliked(e.target.value)}
								className="text-base"
							/>
						</CardContent>
					</Card>

					<Card className="border-2 hover:shadow-lg transition-shadow animate-slide-up delay-300">
						<CardHeader>
							<CardTitle className="flex items-center gap-2 text-xl">
								<span className="text-2xl">💪</span>
								{t.preferences.health.title}
							</CardTitle>
							<CardDescription className="text-base">
								{t.preferences.health.description}
							</CardDescription>
						</CardHeader>
						<CardContent className="space-y-4">
							<Input
								placeholder={t.preferences.health.placeholder}
								value={health}
								onChange={(e) => setHealth(e.target.value)}
								className="text-base"
							/>
							<div className="flex gap-2 flex-wrap">
								{t.preferences.health.tags.map((tag) => (
									<Badge
										key={tag}
										variant="outline"
										className="cursor-pointer hover:bg-orange-100 dark:hover:bg-orange-900/40 transition-colors px-3 py-1.5 text-sm"
										onClick={() => setHealth((prev) => prev ? `${prev}, ${tag}` : tag)}
									>
										+ {tag}
									</Badge>
								))}
							</div>
						</CardContent>
					</Card>

					<Card className="border-2 hover:shadow-lg transition-shadow animate-slide-up delay-400">
						<CardHeader>
							<CardTitle className="flex items-center gap-2 text-xl">
								<span className="text-2xl">🌍</span>
								{t.preferences.cuisines.title}
							</CardTitle>
							<CardDescription className="text-base">
								{t.preferences.cuisines.description}
							</CardDescription>
						</CardHeader>
						<CardContent className="space-y-4">
							<Input
								placeholder={t.preferences.cuisines.placeholder}
								value={cuisines}
								onChange={(e) => setCuisines(e.target.value)}
								className="text-base"
							/>
							<div className="flex gap-2 flex-wrap">
								{t.preferences.cuisines.tags.map((tag) => (
									<Badge
										key={tag}
										variant="outline"
										className="cursor-pointer hover:bg-orange-100 dark:hover:bg-orange-900/40 transition-colors px-3 py-1.5 text-sm"
										onClick={() => setCuisines((prev) => prev ? `${prev}, ${tag}` : tag)}
									>
										+ {tag}
									</Badge>
								))}
							</div>
						</CardContent>
					</Card>

					<Button
						onClick={handleSave}
						disabled={isUpdating}
						className={`w-full h-14 text-lg font-semibold shadow-lg hover:shadow-xl transition-all active-press ${
							showSaved
								? "bg-green-500 hover:bg-green-600"
								: "bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600"
						}`}
						size="lg"
					>
						{showSaved ? (
							<span className="flex items-center gap-2">
								<CheckCircle className="h-5 w-5" />
								{t.preferences.saved}
							</span>
						) : isUpdating ? (
							t.preferences.saving
						) : (
							t.preferences.saveButton
						)}
					</Button>
				</div>
			</div>
		</div>
	);
}
